#pragma once

#include "ApplicationSignals.hpp"
#include "ZmqChannelPeriodicPub.hpp"
#include "ZmqMessages.hpp"

#include "net.hpp"


namespace zmq {


/**
 * The Manager class handles messages through a ZeroMQ channel
 */
class Manager
{
public:

  /// Constructor
  Manager(
      std::shared_ptr<app::Signals> const &,
      std::shared_ptr<zmq::Config> const &,
      std::unique_ptr<zmq::ChannelWithPeriodicPub>
  );

  /// The Application Signals
  std::shared_ptr<app::Signals> const app_signals_;

  /// ZeroMQ configuration
  std::shared_ptr<zmq::Config> const zmq_config_;

  /// ZeroMQ Channel
  std::unique_ptr<zmq::ChannelWithPeriodicPub> const zmq_channel_;

  /// Shared summary of arduino's states
  std::shared_ptr<GpioSummary const> const gpio;


private:

  /// Cached summary of arduino's states
  GpioSummary gpio_;

  /**
   * Publishes current GPIO states.
   */
  void publish_gpio();

  /**
   * Called-back when the PP value has changed.
   */
  void proximity_changed(
      arduino::Resistance_t );

  /**
   * Called-back when a relay has changed.
   */
  void relay_changed(
      arduino::RelayIndex,
      arduino::RelayStatus /* previous */,
      arduino::RelayStatus /* current */,
      arduino::Auxiliary );

  /**
   * Called-back when ZeroMQ message received.
   */
  void incoming_zmq_message( net::const_buffer & );

};


} // namespace
