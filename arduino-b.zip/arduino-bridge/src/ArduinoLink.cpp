#include "ArduinoLink.hpp"


// Boost ASIO library
namespace net = boost::asio;


// Boost Range
#include <boost/range/iterator_range.hpp>


// Boost String Library
#include <boost/algorithm/string/find.hpp>
#include <boost/algorithm/string/find_iterator.hpp>


// C++ Standard Library
#include <functional>
using namespace std::placeholders;

#include <iostream>
#include <iomanip>
#include <string>
using std::string;


namespace arduino {



// ---
// --- Constructor ---
// ---

Link::
Link(
    net::io_context & ioc,
    const std::string & usb_filename
  )
  : ioc { ioc }
  , serial { ioc, usb_filename }
  , send_timer { ioc }
{
  initialize();
  async_read_some();
}



// ---
// --- Initialization ---
// ---


void
Link::
initialize()
{
  using net::serial_port;
  serial.set_option( serial_port::baud_rate( 115200 ));
  serial.set_option( serial_port::flow_control( serial_port::flow_control::none ));
  serial.set_option( serial_port::character_size( 8 ));
  serial.set_option( serial_port::parity( serial_port::parity::none ));
  serial.set_option( serial_port::stop_bits( serial_port::stop_bits::one ));

  in_message.encoded = true;
  in_message_length = 0;
}



// ---
// --- Error Handling ---
// ---

void
Link::
handle_error( const std::string & origin, const std::string & error )
{
  std::cerr << origin << ':' << error << std::endl;
}


void
Link::
handle_error_code( const std::string & origin, const net_errcode & ec )
{
  std::cerr << origin << ':' << ec.message() << std::endl;
  // TODO Check error and optionally quits
}



// ---
// --- Messages Sending ---
// ---

void
Link::
send_message( std::size_t length, const void * msg )
{
  // If queue is empty, nothing is being sent right now = we are inactive
  bool inactive = outgoing_messages.empty();

  // Encode message
  memory::InplaceBuffer<10> buffer;
  memcpy( buffer.data(), msg, length );
  buffer.encode( length );

  // Takes ownership of content (because ASIO buffer won't)
  auto& payload = outgoing_messages.emplace( length + 1 /* COBS */ + 2 /* FrameSep */ );

  auto i = payload.begin();
  *i++ = FrameSeparator;
  std::copy( buffer.data(), buffer.data()+length+1, i );
  i += length + 1;
  *i = FrameSeparator;

  // Starts sending if currently inactive
  // else the timer handler will take care of it
  if( inactive )
    send_front_message();
}


void
Link::
send_front_message()
{
  serial.async_write_some(
      net::buffer( outgoing_messages.front() ),
      std::bind( &Link::message_sent_handler, this, _1, _2 ));
}


void
Link::
message_sent_handler( const net_errcode & ec, std::size_t )
{
  if( ec )
    return handle_error_code( "message_sent_handler", ec );

  send_timer.expires_after( send_period );
  send_timer.async_wait(
      std::bind( &Link::message_period_handler, this, _1 ));
}


void
Link::
message_period_handler( const net_errcode & ec )
{
  if( ec )
    return handle_error_code( "message_period_handler", ec );

  // Free memory of current message
  outgoing_messages.pop();

  if( ! outgoing_messages.empty() )
    send_front_message();
}


// ---
// --- Messages Reception ---
// ---

static const string Log_Origin_Input_Handler { "Input Handler" };


void
Link::
async_read_some()
{
  serial.async_read_some(
      net::buffer(in_buffer),
      std::bind( &Link::on_read_some, this, _1, _2 ));
}


void
Link::
on_read_some( const net_errcode& ec, std::size_t buffer_length )
{
  if( ec )
    return handle_error_code( Log_Origin_Input_Handler, ec );

  uint8_t * in_buffer_ptr = in_buffer;
  uint8_t * in_message_ptr = in_message.data() + in_message_length;

  // Put bytes from in_buffer into in_message until we reach a NUL byte.
  // - Check for buffer overflow.
  // - Only decode frame if it is not too long & we have a listener.
  //   Otherwise, just trash the received bytes.

  for( std::size_t i = 0; i < buffer_length; ++i )
  {
    auto byte = *(in_buffer_ptr++);

    if( byte != 0 )
    {
      // COBS encoded size is "Maximum_Message_Length+1"
      if( in_message_length < Maximum_Message_Length + 1 )
        *(in_message_ptr++) = byte;

      // TODO Check for integer overflow
      ++in_message_length;
    }
    else // byte == 0
    {
      if( on_message_received &&
          in_message_length > 1 &&
          in_message_length <= Maximum_Message_Length + 1 )
      {
        in_message.decode( in_message_length );
        on_message_received( in_message_length - 1, in_message.data() );
      }

      // Restart with new message
      in_message_ptr = in_message.data();
      in_message.encoded = true;
      in_message_length = 0;
    }
  }

  async_read_some();
}


} // namespace
