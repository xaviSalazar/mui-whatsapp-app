#pragma once

#include "net.hpp"


#include <boost/asio/io_context.hpp>
#include <boost/asio/posix/stream_descriptor.hpp>
#include <boost/asio/streambuf.hpp>


namespace tool {


class AsyncInput
{
public:

  AsyncInput( net::io_context &, std::size_t buffer_size );

  using handler_t = std::function<void( const net_errcode&, const std::string& )>;

  void async_read_line( handler_t && );

private:

  // --- Input Stream

  net::posix::stream_descriptor in_stream;
  net::streambuf in_buffer;

  void line_handler( const net_errcode&, std::size_t, handler_t );

};


} // namespace
