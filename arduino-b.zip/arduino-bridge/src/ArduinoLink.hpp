#pragma once

#include "net.hpp"

#include "CobsBuffer.hpp"


#include <boost/asio/serial_port.hpp>
#include <boost/asio/steady_timer.hpp>

#include <queue>


namespace arduino {


/**
 * The Link class provides a C++ API to interact with the Arduino
 *
 * \nosubgrouping
 */
class Link
{
public:

  Link( net::io_context &, const std::string & usb_filename );


  static constexpr uint8_t FrameSeparator = 0;


private:

  /**
   * Initializes the Arduino serial stream.
   */
  void initialize();



  // ---
  // --- Asynchronous Networking ---
  // ---

  /** \name Asynchronous I/O
   *
   * Variables for low-level asynchronous I/O.
   *
   */ /// \{

private:

  /// The networking context to be used.
  net::io_context & ioc;

  /// Handler of the serial pseudo-file
  net::serial_port serial;

  /// \}



  // ---
  // --- Error Handling ---
  // ---

  /** \name Error Handling
   *
   * Methods & variables for error handling.
   *
   */ /// \{

private:

  /**
   * Handles a runtime error
   */
  void handle_error( const std::string & origin, const std::string & error );

  /**
   * Handles an I/O error_code
   */
  void handle_error_code( const std::string & origin, const net_errcode & );

  /// \}



  // ---
  // --- Messages Sending ---
  // ---

  /** \name Message Sending
   *
   * Methods & variables for queuing and sending messages to the Arduino.
   *
   * If several messages needs to be sent, they are queued and sent with a
   * delay of #send_period between them.
   *
   */ /// \{

public:

  /// Type of a message
  using message_t = std::vector<uint8_t>;

  /**
   * Puts message into queue for ASAP delivery.
   */
  void send_message( std::size_t, const void * );

private:

  /// Queue for outgoing, pending messages.
  ///
  /// A message must not be removed from the queue before it has been sent
  /// (since net::buffer doesn't take ownership of the memory) nor before the
  /// delay has elapsed (this is the token used by send_message).
  std::queue<message_t> outgoing_messages;

  /**
   * Asynchronously sends first message in queue
   */
  void send_front_message();

  /**
   * Called-back when message has been sent
   */
  void message_sent_handler( const net_errcode &, std::size_t );

  /// Timer to delay messages sending
  net::steady_timer send_timer;

  /// Waiting time between messages
  static constexpr auto send_period = std::chrono::milliseconds( 20 );

  /**
   * The method is called when #send_timer is due
   */
  void message_period_handler( const net_errcode & );

  /// \}



  // ---
  // --- Messages Reception ---
  // ---

  /** \name Message Reception
   *
   * Methods & variables for receiving & parsing messages from the Arduino.
   *
   */ /// \{

public:

  std::function<void( std::size_t, uint8_t const * )> on_message_received;

private:

  /// Maximum size of an incoming message from the Arduino.
  /// We use an arbitrary value to avoid a dependency with the application…
  static constexpr size_t Maximum_Message_Length = 16;

  /// Buffer to store incoming data from Arduino
  uint8_t in_buffer[ (Maximum_Message_Length + 2) * 2 ];

  /// Buffer to store current message from Arduino
  memory::InplaceBuffer<Maximum_Message_Length> in_message;

  /// Size of current (partial) message from Arduino
  uint8_t in_message_length;

  /**
   * Starts an asynchronous reception of incoming data
   */
  void async_read_some();

  /**
   * Parses some bytes received from the Arduino.
   */
  void on_read_some( const net_errcode&, std::size_t );

  /// \}

};


} // namespace
