#pragma once

#include "ApplicationSignals.hpp"
#include "AsyncInput.hpp"
#include "ZmqMessages.hpp"

#include "net.hpp"


#include <memory>


namespace app {


/**
 * The Console class waits for end-user commands and translates them into
 * relays actions.
 */
class Console
{
public:

  Console(
      net::io_context &,
      std::shared_ptr<app::Signals> const &,
      std::shared_ptr<zmq::GpioSummary const> const &
  );


  /// The ASIO context
  net::io_context & ioc_;

  /// The Application Signals
  std::shared_ptr<app::Signals> const app_signals_;

  /// Shared summary of relays' states
  std::shared_ptr<zmq::GpioSummary const> const gpio_;


private:

  void print_keyboard_usage();


  // --- Input Line Management

  tool::AsyncInput input_;

  void wait_for_line();

  void process_error( const net_errcode& );

  void process_line( const net_errcode&, const std::string& );

  void process_action( char action );

};


} // namespace
