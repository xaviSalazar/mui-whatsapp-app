/** \file
 * The "ArduinoMessages" module defines the messages exchanged between Arduino and peer.
 *
 * \see BridgeMessages.h in Arduino's project for the corresponding definitions
 * from the Arduino point of view.
 */
#pragma once


#include "ArduinoTypes.hpp"


#include <cstdint>


namespace arduino {


// ---
// --- Commands
// ---

/**
 * The Command class describes the format of commands sent to Arduino.
 */
struct Command
{
  uint8_t target;
  uint8_t action;
  uint8_t checksum;

  Command( uint8_t id, uint8_t action ) : target{id}, action{action}
  { computeChecksum(); }

  void computeChecksum() { checksum = (~target) xor action xor 0xA5; }
  bool isValid() { return checksum == uint8_t((~target) xor action xor 0xA5); }
};


/// Action value used to ask for resetting the Arduino.
constexpr uint8_t ResetCommand_Action = 0x5A;


// ---
// --- Relays States
// ---

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wpedantic"
// Ignore: ISO C++ prohibits anonymous structs

/**
 * The RelaySummary structure describes the state of a relay, received from Arduino.
 */
union RelaySummary
{
  uint8_t byte;
  struct {
    RelayStatus status :6;   ///< RelayStatus value
    uint8_t     aux2   :1;   ///< True when auxiliary says "closed" (when applicable)
    uint8_t     aux1   :1;   ///< True when auxiliary says "closed" (when applicable)
  };
};

#pragma GCC diagnostic pop

static_assert( sizeof(RelaySummary) == 1, "RelaySummary must fit in a single byte" );


/// The states of all relays.
using RelaysStates = RelaySummary[ RelaysCount ];


// ---
// --- Arduino's Summary
// ---

struct ArduinoSummary
{
  alignas(2)
  RelaysStates relays;

  alignas(2)
  Resistance_t proximity;
};

static_assert( sizeof(ArduinoSummary)
    == (RelaysCount+1)/2*2
    + sizeof(Resistance_t),
    "Unexpected size of ArduinoSummary" );


} // namespace
