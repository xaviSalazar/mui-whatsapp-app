#include "ArduinoManager.hpp"


#include <boost/asio/steady_timer.hpp>


// C++ Standard Library
#include <functional>
using namespace std::placeholders;


namespace arduino {


Manager::
Manager(
    net::io_context & ioc,
    std::shared_ptr<app::Signals> const & sig,
    std::unique_ptr<arduino::Link> arduino,
    std::size_t init_delay_ms
)
: app_signals_ {sig}
, arduino_ {std::move(arduino)}
, proximity_ {InfiniteResistance}
, relays_ { {0xFF}, {0xFF}, {0xFF}, {0xFF}, {0xFF}, {0xFF}, {0xFF} }
{
  static_assert( sizeof(RelaysStates) == 7, "Unexpected size of RelaysStates structure" );

  app_signals_->reset_arduino.connect(
      app::Signals::Group_Process,
      std::bind( &Manager::reset_arduino, this ));

  app_signals_->set_leds.connect(
      app::Signals::Group_Process,
      std::bind( &Manager::set_leds, this, _1 ));

  app_signals_->set_relay.connect(
      app::Signals::Group_Process,
      std::bind( &Manager::set_relay, this, _1, _2 ));

  auto delay_timer = std::make_unique<net::steady_timer>( ioc );
  delay_timer->expires_after( std::chrono::milliseconds( init_delay_ms ));
  delay_timer->async_wait(
      [t=std::move(delay_timer),this]( net_errcode const & ec )
      {
        if( ec ) return;
        end_of_init_delay();
      });

}


void
Manager::
reset_arduino()
{
  Command cmd ( TargetCommandId::ResetArduino, ResetCommand_Action );
  arduino_->send_message( sizeof(cmd), & cmd );
}


void
Manager::
set_leds( uint8_t states )
{
  Command cmd ( TargetCommandId::PlugLeds, states );
  arduino_->send_message( sizeof(cmd), & cmd );
}


void
Manager::
set_relay( RelayIndex idx, RelayRequest req )
{
  Command cmd ( val(idx), val(req) );
  arduino_->send_message( sizeof(cmd), & cmd );
}


void
Manager::
end_of_init_delay()
{
  std::cout << "Listening to Arduino\n";
  arduino_->on_message_received = std::bind(
      &Manager::incoming_arduino_message, this, _1, _2 );
}


void
Manager::
incoming_arduino_message( std::size_t length, uint8_t const * buffer )
{
  if( length == sizeof( ArduinoSummary ))
  {
    auto msg = reinterpret_cast<ArduinoSummary const*>( buffer );
    process_message( * msg );
  }
  else
    std::cout << "Unknown Arduino message\n";
}


void
Manager::
process_message( ArduinoSummary const & msg )
{
  // Analog: Proximity P.
  // Note:
  //   The Arduino already filters the jitter so we can simply do a comparison.
  if( proximity_ != msg.proximity )
  {
    proximity_ = msg.proximity;
    app_signals_->proximity_changed(proximity_);
  }

  // Relays States
  auto & curr_relays = msg.relays;
  for( int i = 0; i < RelaysCount; ++i )
  {

    auto& previous = relays_[i];
    auto& current = curr_relays[i];

    if( previous.byte == current.byte )
      continue;

    app_signals_->relay_changed(
        RelayIndex(i),
        previous.status,
        current.status,
        current.aux1 + 2 * current.aux2 );
  }

  // Cache new values
  std::memcpy( relays_, curr_relays, sizeof(relays_) );
}


} // namespace
