#pragma once

#include "net.hpp"


#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wnon-virtual-dtor"
#include <azmq/socket.hpp>
#pragma GCC diagnostic pop


#include <boost/asio/steady_timer.hpp>

#include <functional>
#include <memory>


/// \brief Namespace for the `ZeroMQ` source code.
namespace zmq {


/// Timer type used by the Channel
using timer = net::steady_timer;

/// Duration type of used timers
using duration = net::steady_timer::duration;



/**
 * The Config class provides the settings needed by the Channel.
 */
struct Config
{
  /// Call-back for incoming messages
  std::function<void( net::const_buffer & )> incoming_message_cb;

  /// The URI to use for publishing
  std::string publisher_uri;

  /// The URI to use for subscription
  std::string subscriber_uri;

  /// True when ZeroMQ sockets must be bound (and not connected to)
  bool are_bind_sockets = true;

  /// Dump configuration to stream
  void dump(std::ostream &);
};

using Config_sp = std::shared_ptr<Config>;


/**
 * The ChannelWithPeriodicPub class provides a bi-directional channel with remote peers.
 */
class ChannelWithPeriodicPub
{
public:

  ChannelWithPeriodicPub( Config_sp &, net::io_context & );


private:

  /// The Configuration to use
  Config_sp const config;


  /** \name ZeroMQ Publisher
   *
   */ /// \{

  /// Asio-based ZeroMQ publishing socket
  azmq::pub_socket pub_sock;


  /// Timer to delay a publication
  timer publish_timer;

  /// Delay before first publication after an update
  static constexpr auto PUBLISH_DELAY = std::chrono::milliseconds( 10 );

  /// Period between publications
  static constexpr auto PUBLISH_PERIOD = std::chrono::milliseconds( 5000 );


  /// Buffer that contains the data to send.
  /// Publication is stopped if buffer is empty.
  net::const_buffer publish_buffer;


  /**
   * Starts the delay before publishing
   */
  void do_publish_wait( duration );

  /**
   * Method called-back when the #publish_timer is due.
   *
   * The delay is restarted.
   */
  void on_publish( net_errcode );

public:

  /**
   * Sets buffer to send and starts publishing.
   */
  void set_publication_content( const net::const_buffer & );

  /// \}



private:

  /** \name ZeroMQ Subscriber
   *
   */ /// \{

  /// Asio-based ZeroMQ subscribing socket
  azmq::sub_socket sub_sock;

  /**
   * Starts waiting asynchronously for the next incoming ZeroMQ message.
   */
  void do_subscriber_async_receive();

  /**
   * Method called-back when something has been received.
   */
  void on_message_received( const net_errcode &, azmq::message &, size_t );

  /// True when incoming messages must be processed
  bool process_messages = false;

  /// Initial delay during which messages are ignored
  static constexpr auto Filter_Delay = std::chrono::milliseconds( 2000 );

  /// Timer to filter accumulated messages
  timer filter_timer;

  /**
   * Method called-back when the #filter_timer is due.
   */
  void on_filter( net_errcode );

  /// \}

};


} // namespace
