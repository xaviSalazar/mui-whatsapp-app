#include "Logger.hpp"


#include <functional>
using namespace std::placeholders;

#include <iostream>


using namespace std;


namespace app {


Logger::
Logger(
    std::shared_ptr<app::Signals> const & sig
)
  : app_signals_ {sig}
{
  app_signals_->reset_arduino.connect(
      app::Signals::Group_Log,
      std::bind( &Logger::reset_arduino, this ));

  app_signals_->proximity_changed.connect(
      app::Signals::Group_Log,
      std::bind( &Logger::proximity_changed, this, _1 ));

  app_signals_->set_leds.connect(
      app::Signals::Group_Log,
      std::bind( &Logger::set_leds, this, _1 ));

  app_signals_->set_relay.connect(
      app::Signals::Group_Log,
      std::bind( &Logger::set_relay, this, _1, _2 ));

  app_signals_->relay_changed.connect(
      app::Signals::Group_Log,
      std::bind( &Logger::relay_changed, this, _1, _2, _3, _4 ));
}


void
Logger::
reset_arduino()
{
  cout << "RESET of Arduino requested" << std::endl;
}


void
Logger::
proximity_changed( arduino::Resistance_t value )
{
  cout << "PP = " << value << " Ohm\n";
}


void
Logger::
set_leds( uint8_t states )
{
  cout
    << "Plug LEDs: "
    << (states & 1 ? "GRN" : "grn")
    << ' '
    << (states & 2 ? "RED" : "red")
    << '\n';
}


void
Logger::
set_relay( arduino::RelayIndex idx, arduino::RelayRequest req )
{
  cout << idx << " < " << req << " request" << std::endl;
}


void
Logger::
relay_changed(
    arduino::RelayIndex i,
    arduino::RelayStatus previous,
    arduino::RelayStatus current,
    arduino::Auxiliary)
{
  cout << i << " > " << previous << " > " << current << std::endl;
}


} // namespace
