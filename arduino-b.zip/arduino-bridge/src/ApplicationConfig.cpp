#include "ApplicationConfig.hpp"


#include <filesystem>


namespace app {


void Config::read( std::string filepath )
{
  if( std::filesystem::exists( filepath ))
    data = toml::parse( filepath );
  else
  {
    create_default();
    save( filepath );
  }

}


void Config::save( std::string filepath ) const
{
  std::ofstream ofs(filepath, std::ios_base::trunc);
  ofs << data;
}


void Config::create_default()
{
  data = {
    { "arduino", {
      { "file", "/dev/ttyACM0" },
      { "start-delay-ms", 2000 },
    }},
    { "zeromq-relays", {
      { "pub-bind", "tcp://127.0.0.1:6609" },
      { "sub-bind", "tcp://127.0.0.1:6610" },
    }},
  };
}


} // namespace
