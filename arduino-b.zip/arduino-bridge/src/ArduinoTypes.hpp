/** \file
 * The "ArduinoTypes" file provides enumerations & definitions shared with Arduino.
 *
 * \see BridgeTypes.h in Arduino's project for the corresponding definitions
 * from the Arduino point of view.
 *
 * \see GpioTypes.hpp in Main app project for the ZMQ peer definitions.
 */
#pragma once


#include <cstdint>
#include <iostream>


namespace arduino {


// ---
// --- Commands Definitions
// ---

/**
 * IDs of Command Targets
 */
enum TargetCommandId : uint8_t
{
  PlugLeds = 0x40,      ///< Plug LEDs management
  ResetArduino = 0xA5,  ///< Reset Arduino
};


/// ---
/// --- Relays Indexes (enum)
/// ---

/**
 * Index of the relays of the Monkey Board.
 *
 * \note The order is arbitrary but is shared with the remote peer.
 */
enum class RelayIndex : uint8_t
{
  OBC_PS   = 0, ///< OBC Power Supply (12V)
  OBC_DC   = 1, ///< OBC DC
  WW_PS    = 2, ///< Watt&Well Power Supply (12V)
  WW_DC    = 3, ///< Watt&Well DC
  WW_AC    = 4, ///< Watt&Well AC
  Load     = 5, ///< Load
  PlugLock = 6, ///< Plug's Lock

  COUNT ///< Number of elements
};

/// Explicit conversion of Index value into integer
constexpr uint8_t val( enum RelayIndex i ) { return uint8_t(i); }

/// std::ostream helper for Index value
std::ostream& operator<<(std::ostream&, RelayIndex);


/// Number of relays
constexpr auto RelaysCount = val(RelayIndex::COUNT);


/// ---
/// --- Requests (enum)
/// ---


/**
 * Requested state of a relay
 */
enum class RelayRequest : uint8_t
{
  Open = 0,
  Close = 1,

  COUNT ///< Number of elements
};

/// Explicit conversion of RelayRequest value into integer
constexpr uint8_t val( enum RelayRequest i ) { return uint8_t(i); }

/// Number of different requests
constexpr auto RequestsCount = val(RelayRequest::COUNT);

/// std::ostream helper for RelayRequest value
std::ostream& operator<<(std::ostream&, RelayRequest);



/// ---
/// --- Statuses (enum)
/// ---


/**
 * Arduino status of a relay.
 *
 * When auxiliary feedback is available, the status is based on what is read.
 * Otherwise, the status is a copy of the output command.
 */
enum class RelayStatus : uint8_t
{

  /// Transient state, while waiting for the initial state.
  Initializing = 0,

  /// Unexpected auxiliary feedback.
  Error        = 1,

  /// Relay is open.
  Open         = 2,

  /// Relay is closed.
  Closed       = 3,

  /// Relay is opening and we're debouncing the auxiliary feedback.
  Opening      = 4,

  /// Relay is closing and we're debouncing the auxiliary feedback.
  Closing      = 5,

  /// Number of elements
  COUNT,

};

/// Explicit conversion of Status value into integer
constexpr uint8_t val( enum RelayStatus i ) { return uint8_t(i); }

/// Number of different statuses
constexpr auto StatusesCount = val(RelayStatus::COUNT);

/// std::ostream helper for Status value
std::ostream& operator<<(std::ostream&, RelayStatus);


/// ---
/// --- Auxiliaries (feedbacks)
/// ---

using Auxiliary = uint8_t;


/// ---
/// --- Electrical Units
/// ---

/// Type for electrical resistance value
using Resistance_t = uint16_t;

/// Value for high resistance
constexpr Resistance_t InfiniteResistance { 65535 };


} // namespace
