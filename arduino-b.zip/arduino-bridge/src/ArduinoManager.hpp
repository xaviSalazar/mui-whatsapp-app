#pragma once
/** \file
 * The "ArduinoManager" file exchanges commands & statuses with the Arduino.
 */

#include "ApplicationSignals.hpp"
#include "ArduinoLink.hpp"
#include "ArduinoMessages.hpp"


namespace arduino {


/**
 * The Manager class handles a set of relays.
 */
class Manager
{
public:

  /// Constructor
  Manager(
      net::io_context &,
      std::shared_ptr<app::Signals> const &,
      std::unique_ptr<arduino::Link>,
      std::size_t init_delay_ms
  );


  /// The Application Signals
  std::shared_ptr<app::Signals> const app_signals_;

  /// Link to the Arduino
  std::unique_ptr<Link> const arduino_;


private:

  /**
   * Sends a RESET request to Arduino
   */
  void reset_arduino();

  /**
   * Changes states of LEDs
   */
  void set_leds( uint8_t states );

  /**
   * Requests given action to relay
   */
  void set_relay( RelayIndex, RelayRequest );

  /**
   * Called-back when initializing delay is over.
   */
  void end_of_init_delay();

  /**
   * Called-back when Arduino message received.
   */
  void incoming_arduino_message( std::size_t, uint8_t const * );

  /**
   * Called when a new message must be processed
   */
  void process_message( ArduinoSummary const & );

  /// Current, cached value of the Proximity P. line
  Resistance_t proximity_;

  /// Current, cached states of relays
  RelaysStates relays_;
};


} // namespace
