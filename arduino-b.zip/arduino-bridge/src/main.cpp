#include "ApplicationConfig.hpp"
#include "ApplicationSignals.hpp"
#include "ArduinoManager.hpp"
#include "Console.hpp"
#include "Logger.hpp"
#include "ZmqChannelPeriodicPub.hpp"
#include "ZmqManager.hpp"


#include "net.hpp"
#include <boost/asio/signal_set.hpp>


using namespace std;


int
main( int, char** argv )
{

  // ---
  // ---  Configuration
  // ---

  string app_name { argv[0] };
  string toml_filename = app_name + ".toml";

  app::Config app_cfg;
  app_cfg.read( toml_filename );


  // ---
  // --- ASIO Initialization
  // ---

  // -- Context
  //
  // We use a SINGLE thread.
  //
  // If we need more, we must change the way the Manager accesses the data
  // to send!
  net::io_context ioc { 1 };

  // -- Handler for end-user interrupt
  net::signal_set signals( ioc, SIGINT, SIGTERM );
  signals.async_wait( [&ioc](const boost::system::error_code&, int signal)
    {
      cerr << "\rSignal " << signal << " received.\n";
      ioc.stop();
    });


  // ---
  // --- Configuration
  // ---

  auto arduino_cfg = toml::find( app_cfg.data, "arduino" );

  auto arduino_filename = toml::find<string>( arduino_cfg, "file" );
  auto arduino_delay_ms = toml::find<std::size_t>( arduino_cfg, "start-delay-ms" );

  // --- ZeroMQ: Relays channel
  auto relays_cfg = toml::find( app_cfg.data, "zeromq-relays" );

  auto zmq_relays_config = make_shared<zmq::Config>();
  zmq_relays_config->publisher_uri = toml::find<string>( relays_cfg, "pub-bind" );
  zmq_relays_config->subscriber_uri = toml::find<string>( relays_cfg, "sub-bind" );
  zmq_relays_config->are_bind_sockets = true;

  cout << "\nRelays ";
  zmq_relays_config->dump( cout );


  // ---
  // --- Application
  // ---

  // --- Signals
  auto app_signals = make_shared<app::Signals>();

  // --- Logger
  app::Logger logger ( app_signals );

  // --- Arduino Serial Link
  unique_ptr<arduino::Link> link;
  try {
    link = make_unique<arduino::Link>( ioc, arduino_filename );
  }
  catch( boost::system::system_error& e )
  {
    cerr
      << "\n\nCannot connect to Arduino (" << arduino_filename << ")\n"
      << e.what() << endl;
    return EXIT_FAILURE;
  }

  // --- Arduino Manager
  arduino::Manager arduino_manager(
      ioc,
      app_signals,
      std::move(link),
      arduino_delay_ms);

  // --- ZeroMQ Manager
  zmq::Manager zmq_manager(
      app_signals,
      zmq_relays_config,
      make_unique<zmq::ChannelWithPeriodicPub>( zmq_relays_config, ioc ));

  auto gpio_summary = zmq_manager.gpio;

  // --- Console UI
  app::Console console(
      ioc,
      app_signals,
      gpio_summary );


  // ---
  // --- ASIO Loop
  // ---

  ioc.run();

  return EXIT_SUCCESS;
}
