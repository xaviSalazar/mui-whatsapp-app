#include "ZmqManager.hpp"


using namespace arduino;


#include <boost/core/null_deleter.hpp>


// C++ Standard Library
#include <functional>
using namespace std::placeholders;


namespace zmq {


Manager::
Manager(
    std::shared_ptr<app::Signals> const & sig,
    std::shared_ptr<zmq::Config> const & zmq_cfg,
    std::unique_ptr<zmq::ChannelWithPeriodicPub> zmq_chan
)
: app_signals_ {sig}
, zmq_config_ {zmq_cfg}
, zmq_channel_ {std::move(zmq_chan)}
, gpio { &gpio_, boost::null_deleter() }
, gpio_ {
  {
    { RelayRequest::Open, RelayStatus::Initializing, 0 }, // OBC Power Supply (12V)
    { RelayRequest::Open, RelayStatus::Initializing, 0 }, // OBC DC
    { RelayRequest::Open, RelayStatus::Initializing, 0 }, // Watt&Well Power Supply (12V)
    { RelayRequest::Open, RelayStatus::Initializing, 0 }, // Watt&Well DC
    { RelayRequest::Open, RelayStatus::Initializing, 0 }, // Watt&Well AC
    { RelayRequest::Open, RelayStatus::Initializing, 0 }, // Load
    { RelayRequest::Open, RelayStatus::Initializing, 0 }, // Plug Lock
  },
  InfiniteResistance
}
{
  static_assert( RelaysCount == 7, "Unexpected change in number of relays" );

  app_signals_->proximity_changed.connect(
      app::Signals::Group_Listen,
      std::bind( &Manager::proximity_changed, this, _1 ));

  app_signals_->relay_changed.connect(
      app::Signals::Group_Listen,
      std::bind( &Manager::relay_changed, this, _1, _2, _3, _4 ));

  zmq_config_->incoming_message_cb =
    std::bind( &Manager::incoming_zmq_message, this, _1 );
}


void
Manager::
publish_gpio()
{
  zmq_channel_->set_publication_content(
      net::buffer( &gpio_, sizeof(gpio_) ));
}


void
Manager::
proximity_changed(
    Resistance_t value )
{
  gpio_.proximity = value;
  publish_gpio();
}


void
Manager::
relay_changed(
    RelayIndex i,
    RelayStatus /* previous */,
    RelayStatus current,
    Auxiliary aux )
{
  auto& relay = gpio_.relays[ val(i) ];
  relay.status = current;
  relay.auxiliary = aux;

  publish_gpio();
}


void
Manager::
incoming_zmq_message( net::const_buffer & msg)
{
  if( msg.size() == sizeof( RemoteCommand ))
  {
    auto command = reinterpret_cast<RemoteCommand const *>(msg.data());
    if( command->isValid() )
      app_signals_->set_relay(
          RelayIndex(command->target),
          RelayRequest(command->action) );
  }
  else
    std::cout << "Unknown ZMQ message\n";
}


} // namespace
