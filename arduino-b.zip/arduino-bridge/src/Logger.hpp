#pragma once


#include "ApplicationSignals.hpp"


#include <memory>


namespace app {


/**
 * The Logger class logs events as they occur.
 */
class Logger
{
public:

  /// Constructor
  Logger(
      std::shared_ptr<app::Signals> const &
  );

  /// The Application Signals
  std::shared_ptr<app::Signals> const app_signals_;

private:


  // --- Arduino Miscellaneous

  void reset_arduino();


  // --- LEDs

  void set_leds(
      uint8_t states );


  // --- Analog Measures

  void proximity_changed(
      arduino::Resistance_t value );


  // --- Relays

  void set_relay(
      arduino::RelayIndex,
      arduino::RelayRequest );

  void relay_changed(
      arduino::RelayIndex,
      arduino::RelayStatus previous,
      arduino::RelayStatus current,
      arduino::Auxiliary );

};


} // namespace
