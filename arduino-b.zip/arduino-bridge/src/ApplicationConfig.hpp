#pragma once


#include <toml.hpp>


/// \brief Namespace for the application specific source code.
namespace app {


/**
 * The Config class provides read & write methods for the application
 * configuration.
 */
struct Config
{

  void read( std::string filepath );

  void save( std::string filepath ) const;

  void create_default();

  toml::value data;

};


} // namespace
