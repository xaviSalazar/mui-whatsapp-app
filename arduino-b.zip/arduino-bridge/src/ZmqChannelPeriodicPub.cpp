#include "ZmqChannelPeriodicPub.hpp"


#include <functional>
using namespace std::placeholders;

#include <iostream>
using namespace std;


namespace zmq {


// ---
// --- Configuration
// ---

void
Config::
dump(ostream & o)
{
  o << "zeroMQ:\n"
    "  publisher  = " << publisher_uri << "\n"
    "  subscriber = " << subscriber_uri << "\n"
    "  type       = " << ( are_bind_sockets? "bind\n" : "connect\n" );
}


// ---
// --- Constructor
// ---

ChannelWithPeriodicPub::
ChannelWithPeriodicPub( Config_sp & cfg, net::io_context & ioc )
  : config { cfg }

  // Publisher
  , pub_sock { ioc }
  , publish_timer { ioc }

  // Subscriber
  , sub_sock { ioc }
  , filter_timer { ioc }
{
  // Configuration
  if( config->are_bind_sockets )
  {
    pub_sock.bind( config->publisher_uri );
    sub_sock.bind( config->subscriber_uri );
  }
  else
  {
    pub_sock.connect( config->publisher_uri );
    sub_sock.connect( config->subscriber_uri );
  }

  // Accept all incoming data
  sub_sock.set_option(azmq::socket::subscribe( (const void*)nullptr, 0 ));
  do_subscriber_async_receive();

  // Filter accumulated incoming messages
  filter_timer.expires_after( Filter_Delay );
  filter_timer.async_wait(
      std::bind( &ChannelWithPeriodicPub::on_filter, this, _1 ));
}



// ---
// --- Publisher
// ---

void
ChannelWithPeriodicPub::
do_publish_wait( duration delay )
{
  publish_timer.expires_after( delay );
  publish_timer.async_wait(
      std::bind( &ChannelWithPeriodicPub::on_publish, this, _1 ));
}


void
ChannelWithPeriodicPub::
on_publish( net_errcode ec )
{
  if( ec )
    return; // Timer has been cancelled

  if( publish_buffer.size() == 0 )
    return; // Publication has been cancelled

  do_publish_wait( PUBLISH_PERIOD ); // Publish periodically

  pub_sock.send( publish_buffer );
}


void
ChannelWithPeriodicPub::
set_publication_content( const net::const_buffer & buf )
{
  publish_buffer = buf;

  // Wait for additional changes before publishing...
  do_publish_wait( PUBLISH_DELAY );
}



// ---
// --- Subscriber
// ---

void
ChannelWithPeriodicPub::
do_subscriber_async_receive()
{
  sub_sock.async_receive(std::bind(
        &ChannelWithPeriodicPub::on_message_received, this, _1, _2, _3 ));
}

void
ChannelWithPeriodicPub::
on_message_received(
    const net_errcode & ec,
    azmq::message & msg,
    size_t )
{
  if( ec )
  {
    cerr << "SUB handler: " << ec.message() << " (" << ec << ')' << endl;
    return;
  }

  // Ignore multipart messages
  if( msg.more() )
  {
    net_errcode err;
    while( msg.more() )
      sub_sock.receive( msg, 0, err );
  }
  else if( process_messages && config->incoming_message_cb )
  {
    net::const_buffer buffer { msg };
    config->incoming_message_cb( buffer );
  }

  do_subscriber_async_receive();
}


void
ChannelWithPeriodicPub::
on_filter( net_errcode )
{
  process_messages = true;
}


} // namespace
