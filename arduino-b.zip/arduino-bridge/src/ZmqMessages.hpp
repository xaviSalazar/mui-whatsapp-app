/** \file
 * The "ZmqMessages" module defines the messages exchanged with a ZeroMQ peer.
 *
 * \see GpioMessages.hpp in Main app project for the ZMQ peer definitions
 */
#pragma once


#include "ArduinoTypes.hpp"


namespace zmq {


// ---
// --- Commands
// ---

/**
 * The RemoteCommand class describes the format of commands sent to Arduino.
 */
struct RemoteCommand
{
  uint8_t target;
  uint8_t action;
  uint8_t checksum;

  RemoteCommand( uint8_t t, uint8_t a )
  : target{t}
  , action{a}
  {
    computeChecksum();
  }

  void computeChecksum() { checksum = (~target) xor action xor 0xA5; }
  bool isValid() const { return checksum == uint8_t((~target) xor action xor 0xA5); }
};


// ---
// --- Statuses
// ---

/**
 * State of a relay (requested state & feedback)
 */
struct RelayState
{
  arduino::RelayRequest request;
  arduino::RelayStatus  status;
  arduino::Auxiliary    auxiliary;
};


// ---
// --- Summary
// ---

/**
 * Summary of all states.
 */
struct GpioSummary
{
  RelayState relays[ arduino::RelaysCount ];
  arduino::Resistance_t proximity;
};


} // namespace
