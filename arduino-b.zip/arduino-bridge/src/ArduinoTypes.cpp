#include "ArduinoTypes.hpp"


namespace arduino {


/// ---
/// --- Indexes
/// ---

static const char * IndexStrings[] = {
  "OBC_PS",
  "OBC_DC",
  "WW_PS",
  "WW_DC",
  "WW_AC",
  "Load",
  "Plug",
  "*?*",
};

static_assert( std::size(IndexStrings) == RelaysCount + 1,
    "Unexpected change in number of relays" );

std::ostream& operator<<(std::ostream& out, RelayIndex value)
{
  auto idx = std::min( val(value), RelaysCount );
  out << IndexStrings[idx];
  return out;
}


/// ---
/// --- Requests
/// ---

static const char * RequestStrings[] = {
  "Open",
  "Close",
  "#?#",
};

static_assert( std::size(RequestStrings) == RequestsCount + 1,
    "Unexpected change in number of requests" );

std::ostream& operator<<(std::ostream& out, RelayRequest value)
{
  auto idx = std::min( val(value), RequestsCount );
  out << RequestStrings[idx];
  return out;
}


/// ---
/// --- Statuses
/// ---

static const char * RelayStatusStrings[] = {
  "Initializing",
  "Error",
  "Open",
  "Closed",
  "Opening",
  "Closing",
  "#?#",
};

static_assert( std::size(RelayStatusStrings) == StatusesCount + 1,
    "Unexpected change in number of relay statuses" );

std::ostream& operator<<(std::ostream& out, RelayStatus value)
{
  auto idx = std::min( val(value), StatusesCount );
  out << RelayStatusStrings[idx];
  return out;
}


} // namespace
