#pragma once

#include <boost/asio.hpp>

namespace net = boost::asio;                    // from <boost/asio.hpp>

using net_errcode = boost::system::error_code;

