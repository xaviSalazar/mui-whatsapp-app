#pragma once

#include "ArduinoTypes.hpp"


#include <boost/signals2/signal.hpp>


namespace app {


/**
 * The Signals class provides Signals & Slots shared with the different parts
 * of the application.
 */
struct Signals
{

  /// The connect() group for Logger slots
  static constexpr int Group_Log = 0;

  /// The connect() group for Processing slots
  static constexpr int Group_Process = 1;

  /// The connect() group for Listening slots
  static constexpr int Group_Listen = 2;


  // ---
  // --- Arduino Miscellaneous
  // ---

  /// Signal to request a RESET of the Arduino
  boost::signals2::signal<void()>
    reset_arduino;


  // ---
  // --- LEDs
  // ---

  /// Signal to request a change of the Plug LEDs
  boost::signals2::signal<void(uint8_t)>
    set_leds;


  // ---
  // --- Analog Measures
  // ---

  /// Signal to inform about a new Proximity P. value
  boost::signals2::signal<void(arduino::Resistance_t)>
    proximity_changed;


  // ---
  // --- Relays
  // ---

  /// Signal to request a change for a relay
  boost::signals2::signal<void(
      arduino::RelayIndex,
      arduino::RelayRequest )>
    set_relay;

  /// Signal to inform about the state change of a relay.
  boost::signals2::signal<void(
      arduino::RelayIndex,
      arduino::RelayStatus /* previous */,
      arduino::RelayStatus /* current */,
      arduino::Auxiliary )>
    relay_changed;

};


} // namespace
