#include "Console.hpp"


#include <functional>
using namespace std::placeholders;

#include <iostream>
using namespace std;


namespace app {


// ---
// --- Constructor
// ---

Console::
Console(
    net::io_context & ioc,
    std::shared_ptr<app::Signals> const & sig,
    std::shared_ptr<zmq::GpioSummary const> const & gpio
)
: ioc_ {ioc}
, app_signals_ {sig}
, gpio_ {gpio}
, input_ {ioc_, 20}
{
  print_keyboard_usage();
  wait_for_line();
}


// ---
// --- Input Line Management
// ---

void
Console::
print_keyboard_usage()
{
  using namespace arduino;

  cout
    <<    "+---- lower = open"
        "\n!+--- upper = close"
        "\n!!"
    <<  "\noO OBC PS (" << gpio_->relays[val(RelayIndex::OBC_PS)].status
    << ")\npP OBC DC (" << gpio_->relays[val(RelayIndex::OBC_DC)].status
    << ")\nwW WW  PS (" << gpio_->relays[val(RelayIndex::WW_PS)].status
    << ")\ndD WW  DC (" << gpio_->relays[val(RelayIndex::WW_DC)].status
    << ")\naA WW  AC (" << gpio_->relays[val(RelayIndex::WW_AC)].status
    << ")\nlL   Load (" << gpio_->relays[val(RelayIndex::Load)].status
    << ")\ngG   Plug (" << gpio_->relays[val(RelayIndex::PlugLock)].status
    << ")\n\nR  Force Arduino to RESET\n\n"
    << "PP = " << gpio_->proximity << " Ohm"
    << "\n\n";
}


void
Console::
wait_for_line()
{
  input_.async_read_line( bind( &Console::process_line, this, _1, _2 ));
}


void
Console::
process_error( const net_errcode& ec )
{
  using err = boost::asio::error::misc_errors;

  if( ec == err::eof )
  {
    ioc_.stop();
    return;
  }

  else if( ec == err::not_found )
    cerr << "Input error: Line is too long: Ignored\n";

  else if( ec )
    cerr << "Input error: " << ec.message() << " (" << ec << ')' << endl;
}


void
Console::
process_line( const net_errcode& ec, const string& s)
{
  if( ec )
    process_error( ec );

  else if( s.empty() )
  {
    print_keyboard_usage();
  }
  else
  {
    for( auto action : s )
      process_action( action );
  }

  wait_for_line();
}


void
Console::
process_action( char action )
{
  using namespace arduino;

  auto idx = RelayIndex::COUNT;
  auto req = isupper(action) ? RelayRequest::Close : RelayRequest::Open;

  switch( action )
  {

    case 'o':
    case 'O':
      idx = RelayIndex::OBC_PS;
      break;

    case 'p':
    case 'P':
      idx = RelayIndex::OBC_DC;
      break;

    case 'w':
    case 'W':
      idx = RelayIndex::WW_PS;
      break;

    case 'd':
    case 'D':
      idx = RelayIndex::WW_DC;
      break;

    case 'a':
    case 'A':
      idx = RelayIndex::WW_AC;
      break;

    case 'l':
    case 'L':
      idx = RelayIndex::Load;
      break;

    case 'g':
    case 'G':
      idx = RelayIndex::PlugLock;
      break;

    case 'h':
      static uint8_t plug_leds_state = 0;
      plug_leds_state = (plug_leds_state + 1) % 4;
      app_signals_->set_leds( plug_leds_state );
      break;

    case 'R':
      app_signals_->reset_arduino();
      break;

  }

  if( idx != RelayIndex::COUNT )
    app_signals_->set_relay( idx, req );

}


} // namespace
