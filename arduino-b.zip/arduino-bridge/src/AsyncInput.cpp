#include "AsyncInput.hpp"


#include <boost/asio/read_until.hpp>

#include <functional>
using namespace std::placeholders;

#include <iostream>
using namespace std;


namespace tool {


// ---
// --- Constructor
// ---

AsyncInput::AsyncInput( net::io_context & io, std::size_t buffer_size ) :
  in_stream { io, ::dup(STDIN_FILENO) },
  in_buffer { buffer_size }
{
}


// ---
// --- Async Waits
// ---

void AsyncInput::async_read_line( handler_t && h )
{
  net::async_read_until(
      in_stream, in_buffer, '\n',
      std::bind( &AsyncInput::line_handler, this, _1, _2, std::move(h) ));
}


// ---
// --- Input Stream
// ---

void AsyncInput::line_handler(
    const net_errcode& ec,
    std::size_t length,
    handler_t h)
{
  if( ec )
  {
    in_buffer.consume( in_buffer.size() );

    // Check for too-long line
    net_errcode ec2 = ec;
    while( ec2 == net::error::misc_errors::not_found )
    {
      // Yes, too long: purge till newline
      length = net::read_until( in_stream, in_buffer, '\n', ec2 );
      in_buffer.consume( in_buffer.size() );
    }

    h( ec, {} );
  }
  else
  {
    auto bufs = in_buffer.data();
    std::string line(
        net::buffers_begin(bufs),
        net::buffers_begin(bufs) + length - 1);
    in_buffer.consume( length );

    h( ec, line );
  }
}


} // namespace
