# Nano-GPIO-Bridge {#mainpage}

This application is a stand-alone program to interact with the GPIO board of
the Monkey Board.

The end-user can open & close the relays of the MB.
The program reads the states of the relays and sets the LEDs accordingly.


## Usage

The application is invoked with the path to the TTY file created when
connecting the board.

```
$ ./gpio /dev/ttyACM0
```


### Line Interface

The User-Interface is _line oriented_.
Actions are processed only when the end-user presses the _Return_ key.
An action is a single letter;
it is possible to put several actions (_i.e._ letters) on a single line.
They will be processed in order, from left to right.

An **uppercase** letter closes the relay while the corresponding **lowercase**
letter opens it.

- **W** — W&W Power     - Relay #10 - GPIO pin 27
- **D** — W&W DC Relay  - Relay #5 - GPIO pin 29
- **A** — W&W AC Relay  - Relay #7 - GPIO pin 30
- **L** — Load Relay    - Relay #8 - GPIO pin 31
- **S** — SAIC Power    - Relay #9 - GPIO pin 26
- **Q** — SAIC DC Relay - Relay #6 - GPIO pin 28


\namespace gpio         \brief Namespace for the management of the GPIO pins.
\namespace tool         \brief Utility namespace to hold generic classes.
