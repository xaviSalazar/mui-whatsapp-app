var searchData=
[
  ['timestamp_5ft_0',['timestamp_t',['../namespacebridge.html#a7520ec3b9734471015515cca47953706',1,'bridge::timestamp_t()'],['../namespacerelay.html#adad05956c5538cddba1501137652deea',1,'relay::timestamp_t()']]]
];
