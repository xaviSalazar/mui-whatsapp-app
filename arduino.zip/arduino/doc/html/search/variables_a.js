var searchData=
[
  ['name_0',['name',['../structmonkey_1_1SimpleRelay.html#a1bddd2e1f1b124fc74605fab9b147ca7',1,'monkey::SimpleRelay::name()'],['../classmonkey_1_1MonkeyRelay.html#a8ef583f276ea996ace9d0dbe7402f0b8',1,'monkey::MonkeyRelay::name()']]],
  ['nexttimeevent_1',['nextTimeEvent',['../classrelay_1_1VirtualRelay.html#a28bcb0148af4a94806fc155bef7ba6ad',1,'relay::VirtualRelay']]]
];
