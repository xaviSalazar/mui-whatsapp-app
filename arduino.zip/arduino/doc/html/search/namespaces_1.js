var searchData=
[
  ['bridge_0',['bridge',['../namespacebridge.html',1,'']]]
];
