var searchData=
[
  ['arduinosummary_0',['ArduinoSummary',['../structbridge_1_1ArduinoSummary.html',1,'bridge']]]
];
