var searchData=
[
  ['virtualrelay_0',['VirtualRelay',['../classrelay_1_1VirtualRelay.html',1,'relay']]]
];
