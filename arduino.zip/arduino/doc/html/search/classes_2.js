var searchData=
[
  ['global_5ft_0',['Global_t',['../structhardware_1_1Global__t.html',1,'hardware']]]
];
