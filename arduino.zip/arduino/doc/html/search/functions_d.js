var searchData=
[
  ['send_0',['send',['../namespaceserial.html#a0d475c631389568934997279545d0a26',1,'serial']]],
  ['send_5floop_1',['send_loop',['../namespacebridge.html#ae53a2ee4c108899f17cdabe506896dba',1,'bridge']]],
  ['set_5fplug_5fled_2',['set_plug_led',['../namespacemonkey.html#a45ff36c0f868e2d3e684514bcde1d8f0',1,'monkey']]],
  ['setactivechannels_3',['setActiveChannels',['../namespaceadc.html#a19336c2cbd0b3f0d1c16be2ea91af09b',1,'adc']]],
  ['setdigitaloutputs_4',['setDigitalOutputs',['../namespacepio.html#a79540f5ab7f77435c562183de2d04894',1,'pio']]],
  ['setup_5',['setup',['../main_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d',1,'main.cpp']]],
  ['size_6',['size',['../RelayManager_8cpp.html#a9a659553a1c64a054e34c128c06fad9b',1,'RelayManager.cpp']]],
  ['starttimer_7',['startTimer',['../classrelay_1_1VirtualRelay.html#a33686c421760db900bd74e0556519bae',1,'relay::VirtualRelay']]],
  ['stoptimer_8',['stopTimer',['../classrelay_1_1VirtualRelay.html#ae855bb1e149baeb0f312a313088abdb2',1,'relay::VirtualRelay']]],
  ['switch_5fto_9',['switch_to',['../structmonkey_1_1SimpleRelay.html#a2b8e4b5925ff74d77de12c9d63a05d40',1,'monkey::SimpleRelay::switch_to()'],['../classrelay_1_1VirtualRelay.html#a395dfc270d8259ed9e525bbf7a0b1aac',1,'relay::VirtualRelay::switch_to()']]]
];
