var searchData=
[
  ['frameseparator_0',['FrameSeparator',['../namespaceserial.html#abe6ad8d089b18c189f0450f0e9e69c3a',1,'serial']]]
];
