var searchData=
[
  ['read_0',['read',['../namespacepio.html#afab6818f76cab41756095d4e23609733',1,'pio']]],
  ['readoutput_1',['readOutput',['../namespacepio.html#a38f1ef126bf59583efc4b5cac9aa0781',1,'pio']]],
  ['receive_5floop_2',['receive_loop',['../namespaceserial.html#af8af0890c4416e236405e629deee2702',1,'serial']]],
  ['relay_5fchanged_3',['relay_changed',['../namespacebridge.html#ad4aad8733e7aadb28763fd1512510d60',1,'bridge::relay_changed(RelayIndex, bool aux)'],['../namespacebridge.html#af09f3566247b6778694dbfbbfc8f3f0e',1,'bridge::relay_changed(RelayIndex, bool aux[2])']]],
  ['relay_5fstatus_5fchanged_4',['relay_status_changed',['../namespacebridge.html#af623df3d3a61e64632b020b39cc0c144',1,'bridge']]]
];
