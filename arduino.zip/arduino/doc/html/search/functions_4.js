var searchData=
[
  ['forceglobalchange_0',['forceGlobalChange',['../namespaceadc.html#ad0722baa9a9f71588940c69511e96397',1,'adc::forceGlobalChange()'],['../namespacepio.html#a3b18691275181d11ecb7d87626bdce60',1,'pio::forceGlobalChange()']]]
];
