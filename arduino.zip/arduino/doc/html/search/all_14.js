var searchData=
[
  ['_7evirtualrelay_0',['~VirtualRelay',['../classrelay_1_1VirtualRelay.html#ac4af853726fd3b00e487cf99e5f789eb',1,'relay::VirtualRelay']]]
];
