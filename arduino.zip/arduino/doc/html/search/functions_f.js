var searchData=
[
  ['virtualrelay_0',['VirtualRelay',['../classrelay_1_1VirtualRelay.html#aab9c880e665eafd9b1ac180d13e6096c',1,'relay::VirtualRelay']]]
];
