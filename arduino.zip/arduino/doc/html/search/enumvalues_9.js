var searchData=
[
  ['switchfailed_0',['SwitchFailed',['../namespacerelay.html#a7b1dbec94e2e464458e562ddecd3605dabf14ba97cedc009b083280658c8d0cb6',1,'relay::SwitchFailed()'],['../namespacerelay.html#a6ae60c1ee367c4983e560e028813e0bdabf14ba97cedc009b083280658c8d0cb6',1,'relay::SwitchFailed()']]],
  ['switchstable_1',['SwitchStable',['../namespacerelay.html#a6ae60c1ee367c4983e560e028813e0bda13cf41bc8c53715ab4d84a3615af0590',1,'relay']]]
];
