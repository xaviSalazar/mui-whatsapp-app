var searchData=
[
  ['feedback_0',['feedback',['../namespacefeedback.html',1,'']]],
  ['forceglobalchange_1',['forceGlobalChange',['../namespaceadc.html#ad0722baa9a9f71588940c69511e96397',1,'adc::forceGlobalChange()'],['../namespacepio.html#a3b18691275181d11ecb7d87626bdce60',1,'pio::forceGlobalChange()']]],
  ['frameseparator_2',['FrameSeparator',['../namespaceserial.html#abe6ad8d089b18c189f0450f0e9e69c3a',1,'serial']]]
];
