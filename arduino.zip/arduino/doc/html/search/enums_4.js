var searchData=
[
  ['relayindex_0',['RelayIndex',['../namespacebridge.html#a3706dae6c5de86784a5bba3bc103ca9b',1,'bridge']]],
  ['relaystatus_1',['RelayStatus',['../namespacebridge.html#a46c121dd897ba24104daed2a531edea4',1,'bridge']]]
];
