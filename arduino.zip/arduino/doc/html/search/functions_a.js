var searchData=
[
  ['open_0',['open',['../classrelay_1_1VirtualRelay.html#ab67c6f53d8a603d1fdf678302499647d',1,'relay::VirtualRelay']]]
];
