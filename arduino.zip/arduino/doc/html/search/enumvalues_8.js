var searchData=
[
  ['resetarduino_0',['ResetArduino',['../namespacebridge.html#abc17d1bee72fca8df2654431c17692a0a2c18f19b25404051aedeadda4869ceb8',1,'bridge']]]
];
