var searchData=
[
  ['value_5ft_0',['Value_t',['../namespaceadc.html#a0937c271982415411d0083ed25ee2005',1,'adc']]],
  ['value_5ftype_1',['value_type',['../structmemory_1_1InplaceBuffer.html#aba997ab54da8a838c57d19ab6c4a566a',1,'memory::InplaceBuffer']]]
];
