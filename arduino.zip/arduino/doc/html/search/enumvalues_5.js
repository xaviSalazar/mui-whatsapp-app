var searchData=
[
  ['newstate_0',['NewState',['../namespacerelay.html#a6ae60c1ee367c4983e560e028813e0bdaeae98ae8d6956b6aa7b2db2d0702c9b1',1,'relay']]]
];
