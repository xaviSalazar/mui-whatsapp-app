var searchData=
[
  ['notify_0',['notify',['../classmonkey_1_1MonkeyRelay.html#a735e0d20236f03f297c46c2863ee6c71',1,'monkey::MonkeyRelay::notify()'],['../classrelay_1_1VirtualRelay.html#af5037f5ddaf90086e8d8e99dda285e79',1,'relay::VirtualRelay::notify()']]]
];
