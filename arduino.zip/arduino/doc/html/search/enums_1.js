var searchData=
[
  ['globalstate_0',['GlobalState',['../namespacerelay.html#a44c6120e05295fb102828411eb33e942',1,'relay']]]
];
