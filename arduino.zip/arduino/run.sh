#!/bin/bash


# -
# --- Switch to script folder
# -

DIR=`readlink -f $0`
DIR=`dirname $DIR`
cd $DIR


# -
# --- Check external commands are available
# -

SOCAT=socat
GRCAT=grcat
GRCAT_CFG=arduino.grc

for CMD in $SOCAT $GRCAT; do
  if ! command -v $CMD &> /dev/null
  then
    echo "Command \"$CMD\" could not be found."
    exit 1
  fi
done

if [ ! -e $GRCAT_CFG ]
then
  echo "File \"$GRCAT_CFG\" could not be found."
  exit 2
fi


# -
# --- Retrieve all serial TTYs
# -

# https://stackoverflow.com/questions/8880603/loop-through-an-array-of-strings-in-bash/8880633#8880633

shopt -s nullglob
serials=(/dev/ttyACM*)

echo "Available TTYs:  ${serials[@]}"


# -
# --- Select chosen filename (default = last)
# -

tty_index=$(( ${1:-${#serials[@]}} - 1 ))

filename=${serials[$tty_index]}

if [ -z $filename ]
then
  echo "No TTY chosen."
  exit 3
fi

echo "Choosing TTY #$((1+${tty_index})): $filename"


# -
# --- Configure TTY
# -

BAUDRATE=115200

stty -F $filename $BAUDRATE \
  raw \
  -hup \
  -iexten \
  -echo -echoe -echok -echoctl -echoke

echo -e "\nTTY Configuration:"
stty -F $filename


# -
# --- Commands summary
# -

cat <<EOF


Commands Keys
-=-=-=-=-=-=-
!  Toggle Debug Logs
R  Reset Arduino
<space>  Dumps states

oO OBC Power (open/close)
pP OBC DC Relay (open/close)
wW WW Power (open/close)
dD WW DC Relay (open/close)
aA WW AC Relay (open/close)
lL Load Relay (open/close)

gG Plug Lock( open/close)
h  Plug LEDs
EOF


# -
# --- Start monitoring
# -

$SOCAT STDIO $filename | $GRCAT $GRCAT_CFG

