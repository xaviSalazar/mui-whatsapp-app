#!/bin/bash

BOSSAC=/home/vedecom/dev/BOSSA-1.6.1-arduino/bin/bossac 

# -
# --- Retrieve all serial TTYs
# -

# https://stackoverflow.com/questions/8880603/loop-through-an-array-of-strings-in-bash/8880633#8880633

shopt -s nullglob
serials=(/dev/ttyACM*)

echo "Available TTYs:"
for TTY in ${serials[@]}; do
  echo "  - $TTY"
done


# -
# --- Select chosen filename (default = last)
# -

tty_index=$(( ${1:-${#serials[@]}} - 1 ))

filename=${serials[$tty_index]}

if [ -z $filename ]
then
  echo "No TTY chosen."
  exit 3
fi

echo -e "\nAbout to ERASE Arduino on ${filename}!\nARE YOU SURE?"
echo -n "[Enter] to confirm, [Ctrl-C] to abort "
read


# -
# --- Reset Arduino
# -

echo "Erasing..."
stty -F $filename 1200 raw
sleep 1


# -
# --- Upload code to Arduino
# -

echo "Waiting for Arduino..."
stty -F $filename 115200 raw
sleep 1

$BOSSAC --info --port=`basename $filename` --force_usb_port=false --erase --write  --boot --reset "src.ino.bin"

