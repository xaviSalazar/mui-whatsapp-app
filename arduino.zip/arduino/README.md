# Arduino as the Relays Manager {#mainpage}

\tableofcontents

## Usage

The Arduino communicate through both USB ports.

![Arduino USB ports](../Arduino-USBs.png)

The _USB Prog_ port, near the _power barrel jack_, is used for the
Machine-to-machine stream.
It is a COBS-encoded stream used to receive relays commands and send feedbacks.

The _USB Native_ port, near the _reset_ button, is an optional, text-oriented debug flow.
This stream prints configurable debug logs and accepts simple commands.

The `run.sh` script can be used to configure a full-duplex, coloured (by
`grcat`) text interface.
The available commands are printed by the script;
they are single characters, sent to the Arduino when pressing _Enter_.

Both streams use a 115 200 baudrate.


The **L** LED is used as a visual feedback.
When operating properly, it should make a double flash every second.


## Hardware Pinout

The pinout is summarized in the `src/Hardware.ods` _calc sheet_.
See the Global Hardware layout of the project for the pinout used by the Arduino.

In case of change, this sheet produces line #3 the values that must be provided
to the src/Hardware.cpp file for configuring the _PIO_ module of the Arduino
after a _reset_.
This is the raw, global configuration of the GPIOs.

The calc sheet also provides column **D** the port names (i.e. _A_, _B_, _C_
and _D_) and column **E** the pin number of the used pins.
The input pins are declared in MonkeyIO.h, and the output pins in monkey::init.


## Software Architecture

### Third-Party Libraries

The project uses the [Scheduler library](https://github.com/m-dhooge/Arduino-Scheduler.git)
to provide an easy way to have several loops run in parallel.
However, the switch between loops is **not pre-emptive**.
That means less efforts are needed to avoid race conditions and concurrent
accesses to shared data.
But this also means that every loops must behave cleanly and not hog the MPU
for too long.

Control is returned to the Scheduler when a `loop()` method returns.
And it is also possible to call the `Scheduler.yield()` to temporarily suspend
a long-running process.

The [DebugUtils](https://github.com/arduino-libraries/Arduino_DebugUtils)
is used to ease printing messages to the USB serial console.


### Arduino MPU Configuration & Management

The src/Hardware.cpp and src/ParallelIO.cpp files configures and manages the
Atmel MPU of the Arduino.
They have zero knowledge of how the GPIO pins are used by the application.

This is here that the conversion between **logical** (_i.e._ true/false) and
**electrical** (0 V/3.3 V) levels is done, according to what is described in
the calc sheet.


### Debug Interface

src/Console.cpp provides the _debug_ Text User Interface that is available on the
USB _native_ port.
It dumps events and accepts commands (_i.e._ single characters) to change
relays states.

src/LedFeedback.cpp provides a visual feedback to the operator.
When the Arduino is operating properly, the **L** LED should make a double
flash every second.


### Machine-to-machine USB Stream

src/SerialMonitor.cpp provides the low-level interaction with the Arduino's
USB Serial hardware.
The background listening loop, serial::receive_loop, calls bridge::process_command when
a valid Command is received.
The serial::send method is used to synchronously send a feedback (it only
returns when sent).

src/CobsBuffer.h provides an implementation of the COBS coding algorithm.
This algorithm efficiently removes all zeroes from the data sent;
the zero value can then be used as a separator to synchronized reception.


src/BridgeManager.cpp provides the translation layer for the messages exchanged
with the remote peer.
Commands received from the peer are forwarded to the #monkey module to operate
on the corresponding relay.
Relays statuses are periodically send back.

\note
  The statuses are sent periodically and not on every changes.
  This is unrelated to the way events are handled internally (i.e. they are
  handled as they occur).

src/BridgeMessages.h defines the structures of the messages and
src/BridgeTypes.h the enumerations used.


### Relays Management

src/RelayManager.cpp provides the relay::RelayManager class.
This class is agnostic of the way the relay it controls is really monitored and
actioned.
It uses methods to interact with the #monkey module, that knows the details of
the Monkey Board.

![State Machine](../RelayManager.png)

src/MonkeyIO.cpp defines variables that describe the pinout of the Board.
The inputs are grouped according to relays auxiliaries.
The outputs (relays & LEDs commands) are defined with either
monkey::SimpleRelay or monkey::MonkeyRelay instances (depending on whether
auxiliaries feedbacks are available).

src/MonkeyRelays.cpp defines the monkey::MonkeyRelay class that extends
relay::RelayManager.
This is this class that handles the LED visual feedback.

The states of the auxiliaries feedbacks are pushed to the relay::RelayManager class
by monkey::digital_monitor.
Depending on the number of auxiliaries, the method relay::processEvent is
called with the events _Open_, _Closed_ or _Unknown_ (when both auxiliaries are
in different states).


## Example: Closing the W&W DC Relays

This example shows how the application receives, processes and sends feedbacks
when requested to close the W&W DC relays.

1. Let's suppose the W&W DC relay is currently open

2. serial::receive_loop receives a message (a stream of non-zero bytes
   terminated by a 0)
   - memory::InplaceBuffer decodes this COBS data into a supposed bridge::Command
   - [isValid](\ref bridge::Command::isValid) returns `true` if the check-sum
     is correct

3. bridge::process_command
   - checks the [RelayIndex](\ref bridge::RelayIndex) value
   - calls the [switch_to](\ref relay::VirtualRelay::switch_to) method of the
     monkey::relay_WW_DC instance

4. [processEvent](\ref relay::VirtualRelay::processEvent) is called with
   Event::CloseRequest
   - case [Open](\ref relay::InternalState::Open)
     - case [CloseRequest](\ref relay::Event::CloseRequest)
       - triggers an [asyncTransitionTo](\ref relay::VirtualRelay::asyncTransitionTo)
         InternalState::Closing_Requested

5. [processTimerEvent](\ref relay::VirtualRelay::processTimerEvent) is called
   with [NewState](\ref relay::TimerId::NewState)

6. [doTransition](\ref relay::VirtualRelay::doTransition) is called

  1. [MonkeyRelay::notify](\ref monkey::MonkeyRelay::notify) is called
     - The LED is lit
     - A log is printed on the debug console
     - bridge::relay_status_changed is called with [RelayStatus](\ref bridge::RelayStatus)`::`Closing
       - the array bridge::currentState is updated

  2. [processEvent](\ref relay::VirtualRelay::processEvent) is called with
     Event::OnEntry
     - calls [MonkeyRelay::do_close](\ref monkey::MonkeyRelay::do_close) that
       changes the command output pin
     - starts the [SwitchFailed](\ref relay::TimerId::SwitchFailed) timer
     - triggers an [asyncTransitionTo](\ref relay::VirtualRelay::asyncTransitionTo)
       InternalState::Closing_Debouncing

After some time, the W&W DC relays are closed and the auxiliaries states are
changing accordingly.

1. On the edge of the electrical transition, pio::inputsChanged is set to 1

2. monkey::monitor_loop sees the change and calls monkey::digital_monitor
   - all input pins are processed sequentially and compared with cached values
     - calls [relay_WW_DC](\ref monkey::relay_WW_DC) `->`
       [processEvent](\ref relay::VirtualRelay::processEvent)
       `(`[AuxiliaryClosed](\ref relay::Event::AuxiliaryClosed)`)`

3. The state machine moves to InternalState::Closed_Debouncing
   - starts the [SwitchStable](\ref relay::TimerId::SwitchStable) timer
   - calls doTransition that updates the relays statuses

4. When the timer is due, we have the sequence:
   - processTimerEvent
   - processEvent( Event::AuxiliaryStable )
   - move to state InternalState::Closed
   - calls doTransition that updates the relays statuses

Independently of this sequence, bridge::send_loop periodically sends the global
statuses of the relays to the peer.
