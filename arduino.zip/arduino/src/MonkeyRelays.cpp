#include "MonkeyRelays.h"

#include "BridgeManager.h"


// Third-party Libraries
#include <Arduino_DebugUtils.h>


namespace monkey {

using namespace relay;

/// True when debug logs print internal state change
constexpr bool Debug_PrintInternalState = false;



/// Conversion between internal State Machine state and remote peer status
static const bridge::RelayStatus GlobalStateToBridgeStatus[] =
{
  // Must be sorted in GlobalState order
  bridge::RelayStatus::Open,         // Open
  bridge::RelayStatus::Closed,       // Closed
  bridge::RelayStatus::Error,        // Error
  bridge::RelayStatus::Opening,      // Opening
  bridge::RelayStatus::Closing,      // Closing
  bridge::RelayStatus::Initializing, // Initializing
};


MonkeyRelay::
MonkeyRelay(
    const bridge::RelayIndex idx,
    const char * name,
    const pio::OutputPin & cmd,
    const pio::OutputPin & led )
: index { idx }
, name { name }
, command ( cmd )
, led ( led )
{
}


void
MonkeyRelay::
notify( GlobalState newGlobal, GlobalState oldGlobal,
        InternalState newInternal, InternalState oldInternal)
{
  // The LED is active in all states but open
  pio::write( led, newGlobal != GlobalState::Open );

  if( newGlobal != oldGlobal )
  {
    if( Debug_PrintGlobalStatesAsStrings )
      Debug.print( DBG_INFO, "%s : %s", name, toString( newGlobal ));
    else
      Debug.print( DBG_INFO, "%s : %d", name, newGlobal );

    auto status = GlobalStateToBridgeStatus[ int(newGlobal) ];
    bridge::relay_status_changed( index, status );
  }

  if( newInternal != oldInternal && Debug_PrintInternalState )
    Debug.print( DBG_INFO, "%s  (%s)", name, toString( newInternal ));
}


void
MonkeyRelay::
do_open()
{
  // Debug.print( DBG_DEBUG, "%s: do_open", name );
  pio::write( command, false );
}


void
MonkeyRelay::
do_close()
{
  // Debug.print( DBG_DEBUG, "%s: do_close", name );
  pio::write( command, true );
}



} // namespace
