/** \file
 * Contains the state machine to manage one or more relays and their associated
 * auxiliary feedbacks.
 */
#pragma once


// Third-party Libraries
#include <Arduino.h>


/// This module provides the State Machine to handle debouncing of a relay.
namespace relay {


// ---
// --- State Machine's States
// ---


/** The global, high-level states of the relay.
 *
 * This is the state visible to the outside world, without the internal
 * plumbing during transitions.
 */
enum class GlobalState
{
  Open, ///< The relay is open
  Closed, ///< The relay is closed
  Error, ///< An error was detected
  Opening, ///< Debouncing state while opening
  Closing, ///< Debouncing state while closing
  Initializing, ///< Initialization
};


/** The technical states of relay's during operation.
 */
enum class InternalState
{
  Open, ///< The relay is open

  Closed, ///< The relay is closed

  Error, ///< An error was detected

  Opening_Requested, ///< Change output pin & starts max timer
  Opening, ///< Opening, waiting for auxiliary to debounce

  Closing_Requested, ///< Change output pin & starts max timer
  Closing, ///< Closing, waiting for auxiliary to debounce

  Initializing, ///< Initialization

  Undefined, ///< Internal to SM
};


// ---
// --- State Machine's Events
// ---

enum class Event
{
  OnEntry, /// Internal event: Entry in new state

  OpenRequest, ///< Application request
  CloseRequest, ///< Application request

  AuxiliaryClosed, ///< Input event: Auxiliary is closed
  AuxiliaryUnknown, ///< Input event: Auxiliary undetermined
  AuxiliaryOpen, ///< Input event: Auxiliary is open

  AuxiliaryStable, /// Timer: No changes on auxiliary for some time

  SwitchFailed, /// Timer: Target state not reached within expected time

  COUNT
};


// ---
// --- Time & Timers
// ---
//
// TODO: Handle millis() overflow


enum class TimerId
{
  NewState, ///< Internal to SM: Used to postpone transition
  SwitchFailed, ///< Maximum delay for the relay to switch
  SwitchStable, ///< Delay after which the switch is considered effective

  COUNT
};


/// Timestamp type is the return type of millis() method.
using timestamp_t = decltype( millis() );

/// Use maximum integer value to disable timer
constexpr timestamp_t TimerDisabled = -1;
static_assert( TimerDisabled > 1, "Expecting unsigned type" );


/// Maximum delay to have relay closed
constexpr timestamp_t MaximumClosingTime = 1000; // ms

/// Debounce delay: the relay's auxiliary must not switch during this delay to
/// validate the new state.
constexpr timestamp_t ClosedDebounceDelay = 200; // ms


/// Maximum delay to have relay open
constexpr timestamp_t MaximumOpeningTime = 1000; // ms

/// Debounce delay: the relay's auxiliary must not switch during this delay to
/// validate the new state.
constexpr timestamp_t OpenDebounceDelay = 200; // ms



// ---
// --- Relay Management
// ---

/**
 * The VirtualRelay class provides a canvas to handle a real relay.
 *
 * It uses a state machine to process the inputs.
 */
class VirtualRelay
{
public:

  /// Constructor
  VirtualRelay();

  /// Virtual destructor, since we have virtual methods.
  virtual ~VirtualRelay();

  /**
   * Submits a request to close the relay
   */
  void close()
  { processEvent( Event::CloseRequest ); }

  /**
   * Submits a request to open the relay
   */
  void open()
  { processEvent( Event::OpenRequest ); }

  /**
   * Submits a request to switch to given state
   */
  void switch_to( bool closed )
  { processEvent( closed ? Event::CloseRequest : Event::OpenRequest ); }


  // ---
  // --- State Machine
  // ---

public:

  /// The “summarized” state, to provide a simple status
  GlobalState globalState = GlobalState::Initializing;

  /**
   * Processes an event
   */
  void processEvent( Event );

private:

  /// The real, detailed, internal state
  InternalState currentState = InternalState::Undefined;

  /// The target state for the next transition
  InternalState targetState = InternalState::Undefined;

  /**
   * Sets the new state.
   *
   * \note This uses the Timer loop to process the transition asynchronously.
   *    _i.e._ The transition to the new state won't be effective before the
   *    caller function has yield()-ed.
   */
  void asyncTransitionTo( InternalState );

  /**
   * Changes to new state, stored into targetState
   */
  void doTransition();

  /**
   * Converts time event into SM event
   */
  void processTimerEvent( TimerId );

  /**
   * Triggers a new check of all inputs.
   *
   * \note Normally, all inputs changes are taken into account as events are
   * received.
   * But in case, something was overlooked, this function triggers a new check
   * of all input values.
   * This is done by the ParallelIO module that can create events equivalent to
   * a full toggle of all inputs.
   */
  void asyncInputsCheck();


  // ---
  // --- Timers
  // ---

private:

  /**
   * Returns true when the timer is running and has not been triggered yet.
   */
  bool isTimerActive( TimerId );

  /**
   * Starts (or restarts) timer with given delay.
   */
  void startTimer( timestamp_t delay, TimerId );

  /**
   * Stops timer.
   */
  void stopTimer( TimerId );

  volatile
  timestamp_t nextTimeEvent = TimerDisabled;

  timestamp_t timers[ int( TimerId::COUNT )];

  void computeNextTimeEvent();

  void timer_loop();


  // ---
  // --- Relay Actions
  // ---

private:

  /** Do whatever is needed to open the relay */
  virtual void do_open() = 0;

  /** Do whatever is needed to close the relay */
  virtual void do_close() = 0;


  // ---
  // --- Events Notifications
  // ---

private:

  virtual void notify(
      GlobalState newGlobal, GlobalState oldGlobal,
      InternalState newInternal, InternalState oldInternal) = 0;

};



// ---
// --- Debug Helpers
// ---

/**
 * Returns a string corresponding to state
 */
const char * toString( GlobalState );

/**
 * Returns a string corresponding to state
 */
const char * toString( InternalState );

/**
 * Returns a string corresponding to event
 */
const char * toString( Event );


} // namespace
