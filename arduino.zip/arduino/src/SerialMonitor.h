/** \file
 * Low-level processing of Serial frames.
 */
#pragma once

#include "BridgeMessages.h"


/// Namespace for the Serial communication
namespace serial {


/// Initializes the module.
void init();


/**
 * Sends message through Serial
 *
 * \note Blocks until sent
 */
void send( const bridge::ArduinoSummary & );


} // namespace
