/** \file
 * The _official_ entry point for the whole Arduino software.
 */

#include <Arduino.h>
#include <Arduino_DebugUtils.h>


// Project modules
#include "BridgeManager.h"
#include "Console.h"
#include "Hardware.h"
#include "LedFeedback.h"
#include "MonkeyIO.h"
#include "SerialMonitor.h"


void setup()
{
  // Serial Debug UART
  SerialDebug.begin( hardware::SerialDebug_Baudrate );
  Debug.setDebugOutputStream( & SerialDebug );

  // Modules setup
  Debug.setDebugLevel( DBG_DEBUG );

  hardware::init();
  // => PIO
  // => ADC

  monkey::init();

  console::init();

  feedback::led_setup();

  serial::init();

  bridge::init();

  /* Debug settings for the main loops
   *
   * DBG_NONE - no debug output is shown
   * DBG_ERROR - critical errors
   * DBG_WARNING - non-critical errors
   * DBG_INFO - information
   * DBG_DEBUG - more information
   * DBG_VERBOSE - most information
   */
  console::show_debug_level = false; // Used by the '!' action
  Debug.setDebugLevel( DBG_INFO );
  Debug.timestampOn();
}

void loop()
{
  hardware::watchdogReset();
  feedback::led_loop();
}
