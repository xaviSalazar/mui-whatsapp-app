#include "BridgeManager.h"


// Project modules
#include "BridgeMessages.h"
#include "Hardware.h"
#include "MonkeyIO.h"
#include "SerialMonitor.h"


// Third-party Libraries
#include <Arduino.h>
#include <Arduino_DebugUtils.h>
#include <Scheduler.h>


namespace bridge {


// ---
// --- Definitions
// ---

/// Data type returned by millis()
using timestamp_t = decltype( millis() );

static constexpr timestamp_t SendPeriod = 500; ///< milliseconds

// Forward declaration
static void send_loop();


// ---
// --- Local Variables
// ---

/// Current summary of Arduino state
static
ArduinoSummary arduino_summary {

  // Relays
  {
    { Open         },  // OBC Power Supply (12V)
    { Initializing },  // OBC DC
    { Open         },  // Watt&Well Power Supply (12V)
    { Initializing },  // Watt&Well DC
    { Initializing },  // Watt&Well AC
    { Initializing },  // Load
    { Initializing },  // Plug Lock
  },

  InfiniteResistance, // Proximity P.

};

/// Time when next statuses must be sent
static timestamp_t send_time;


// ---
// --- Module initialization
// ---

void init()
{
  send_time = millis() + SendPeriod;
  Scheduler.startLoop( send_loop );
}



// ---
// --- Commands
// ---

void process_command( const Command * command )
{
  auto action = command->action;

  switch( command->target )
  {

    case OBC_PS:
      monkey::relay_OBC_PS->switch_to( action );
      break;

    case OBC_DC:
      monkey::relay_OBC_DC->switch_to( action );
      break;

    case WW_PS:
      monkey::relay_WW_PS->switch_to( action );
      break;

    case WW_DC:
      monkey::relay_WW_DC->switch_to( action );
      break;

    case WW_AC:
      monkey::relay_WW_AC->switch_to( action );
      break;

    case Load:
      monkey::relay_Load->switch_to( action );
      break;

    case PlugLock:
      monkey::plug_lock->switch_to( action );
      break;

    case PlugLeds:
      monkey::set_plug_led( action );
      break;

    case ResetArduino:
      if( action == ResetCommand_Action ) {
        hardware::resetRequested = true;
        Debug.print( DBG_ERROR, "ERROR: RESET request received from peer" );
      }
      break;

    default:
      Debug.print( DBG_WARNING, "Command: Unknown target ID" );
      break;
  }
}



// ---
// --- Analog Update
// ---

void proximity_changed( Resistance_t value )
{
  arduino_summary.proximity = value;
}


// ---
// --- Relays Statuses
// ---

void relay_status_changed( RelayIndex idx, RelayStatus status )
{
  if( idx >= RelayIndex::COUNT ) return;
  arduino_summary.relays[ idx ].status = status;
}


// ---
// --- Auxiliaries Update
// ---

void relay_changed( RelayIndex idx, bool aux )
{
  if( idx >= RelayIndex::COUNT ) return;
  arduino_summary.relays[ idx ].aux1 = aux;
}


void relay_changed( RelayIndex idx, bool aux[2] )
{
  if( idx >= RelayIndex::COUNT ) return;
  arduino_summary.relays[ idx ].aux1 = aux[0];
  arduino_summary.relays[ idx ].aux2 = aux[1];
}


// ---
// --- Loop
// ---

/// Scheduler loop: Periodically sends the relays statuses
static
void send_loop()
{
  await( GetTickCount() >= send_time );
  send_time += SendPeriod;

  serial::send( arduino_summary );
}


} // namespace
