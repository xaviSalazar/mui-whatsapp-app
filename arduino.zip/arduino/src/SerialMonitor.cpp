#include "SerialMonitor.h"

// Project modules
#include "BridgeManager.h"
#include "CobsBuffer.h"
using memory::InplaceBuffer;
#include "Hardware.h"


// Third-party Libraries
#include <Arduino.h>
#include <Arduino_DebugUtils.h>
#include <Scheduler.h>


namespace serial {


static constexpr uint8_t FrameSeparator = 0;


// ---
// --- Receive
// ---

/// Scheduler loop: Waits for incoming Commands
static
void receive_loop()
{
  static constexpr auto CommandSize = sizeof(bridge::Command);
  static constexpr auto FrameLength = CommandSize + 2; // COBS overhead + NUL

  // Wait for incoming frame
  await( SerialM2M.available() >= FrameLength );

  InplaceBuffer<CommandSize> buffer;
  buffer.encoded = true;

  while( SerialM2M.available() >= FrameLength )
  {
    auto read_bytes = SerialM2M.readBytesUntil(
        FrameSeparator, buffer.data(), CommandSize + 1 );

    if( read_bytes != CommandSize + 1 )
      continue;

    /* Debug.print( DBG_INFO, "Received %d bytes", read_bytes ); */

    buffer.decode( CommandSize + 1 );
    bridge::Command * command = (bridge::Command *) buffer.data();

    if( ! command->isValid() )
      Debug.print( DBG_WARNING, "Command: Bad checksum" );

    else
      bridge::process_command( command );
  }

}


// ---
// --- Send
// ---

void send( const bridge::ArduinoSummary & msg )
{
  static constexpr auto MessageSize = sizeof(msg);

  if( SerialM2M.availableForWrite() < MessageSize + 3 )
    return; // TODO

  // Create COBS-encoded buffer
  InplaceBuffer<MessageSize> buffer;
  memcpy( buffer.data(), &msg, MessageSize );
  buffer.encode( MessageSize );

  // Send bytes
  SerialM2M.write( FrameSeparator );  // Start of frame
  SerialM2M.write( buffer.data(), MessageSize + 1 );
  SerialM2M.write( FrameSeparator );  // End of frame
}


// ---
// --- Module initialization
// ---

void init()
{
  SerialM2M.begin( hardware::SerialM2M_Baudrate );

  Scheduler.startLoop( receive_loop );
}


} // namespace
