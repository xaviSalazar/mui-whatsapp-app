#include "RelayManager.h"


// Project modules
#include "ParallelIO.h"


// Third-party Libraries
#include <Arduino_DebugUtils.h>
#include <Scheduler.h>


// From C++17
template <class T, int N>
constexpr int size(const T (&array)[N]) noexcept { return N; }


namespace relay {


VirtualRelay::
VirtualRelay()
{
  Scheduler.startLoop(
      [this]() { timer_loop(); });

  asyncTransitionTo( InternalState::Initializing );
}


VirtualRelay::
~VirtualRelay()
{
}


// ---
// --- States: Internal to Global
// ---

/// Translation from InternalState to GlobalState
const GlobalState State_InternalToGlobal[] =
{
  GlobalState::Open,         // Open

  GlobalState::Closed,       // Closed

  GlobalState::Error,        // Error

  GlobalState::Opening,      // Opening_Requested
  GlobalState::Opening,      // Opening

  GlobalState::Closing,      // Closing_Requested
  GlobalState::Closing,      // Closing

  GlobalState::Initializing, // Initializing

  GlobalState::Error,        // Undefined
};

static_assert( size(State_InternalToGlobal) == int(InternalState::Undefined) + 1,
    "Different size between states and summaries.");


// ---
// --- State Machine
// ---

void
VirtualRelay::
processEvent( Event event )
{
  switch( currentState )
  {

    case InternalState::Open:
      switch( event )
      {
        case Event::OnEntry:
          asyncInputsCheck(); break;
          // Just to be sure everything is still valid

        case Event::CloseRequest:
          asyncTransitionTo( InternalState::Closing_Requested ); break;

        case Event::AuxiliaryClosed:
        case Event::AuxiliaryUnknown:
          asyncTransitionTo( InternalState::Error ); break;
      }
      break;

    case InternalState::Closed:
      switch( event )
      {
        case Event::OnEntry:
          asyncInputsCheck(); break;
          // Just to be sure everything is still valid

        case Event::OpenRequest:
          asyncTransitionTo( InternalState::Opening_Requested ); break;

        case Event::AuxiliaryOpen:
        case Event::AuxiliaryUnknown:
          asyncTransitionTo( InternalState::Error ); break;
      }
      break;

    case InternalState::Error:
      switch( event )
      {
        case Event::OpenRequest:
          asyncTransitionTo( InternalState::Opening_Requested ); break;
      }
      break;

    case InternalState::Opening_Requested:
      // This is a transient state that goes automatically into debouncing.
      // In some cases (e.g. the command output pin is connected directly to
      // the auxiliary input pin), events are received before we effectively
      // moved into next state, so we share the handling...

    case InternalState::Opening:
      switch( event )
      {
        case Event::OnEntry:
          if( currentState == InternalState::Opening_Requested ) {
            do_open();
            startTimer( MaximumOpeningTime, TimerId::SwitchFailed );
            asyncTransitionTo( InternalState::Opening );
            asyncInputsCheck();
          }
          break;

        case Event::AuxiliaryOpen:
          startTimer( OpenDebounceDelay, TimerId::SwitchStable ); break;

        case Event::AuxiliaryClosed:
        case Event::AuxiliaryUnknown:
          stopTimer( TimerId::SwitchStable ); break;

        case Event::AuxiliaryStable:
          asyncTransitionTo( InternalState::Open ); break;

        case Event::SwitchFailed:
          asyncTransitionTo( InternalState::Error ); break;

        case Event::CloseRequest:
          asyncTransitionTo( InternalState::Closing_Requested ); break;
      }
      break;

    case InternalState::Closing_Requested:
      // This is a transient state that goes automatically into debouncing.
      // In some cases (e.g. the command output pin is connected directly to
      // the auxiliary input pin), events are received before we effectively
      // moved into next state, so we share the handling...

    case InternalState::Closing:
      switch( event )
      {
        case Event::OnEntry:
          if( currentState == InternalState::Closing_Requested ) {
            do_close();
            startTimer( MaximumClosingTime, TimerId::SwitchFailed );
            asyncTransitionTo( InternalState::Closing );
          }
          break;

        case Event::AuxiliaryClosed:
          startTimer( ClosedDebounceDelay, TimerId::SwitchStable ); break;

        case Event::AuxiliaryOpen:
        case Event::AuxiliaryUnknown:
          stopTimer( TimerId::SwitchStable ); break;

        case Event::AuxiliaryStable:
          asyncTransitionTo( InternalState::Closed ); break;

        case Event::SwitchFailed:
          asyncTransitionTo( InternalState::Error ); break;

        case Event::OpenRequest:
          asyncTransitionTo( InternalState::Opening_Requested ); break;
      }
      break;

    case InternalState::Initializing:
      switch( event )
      {
        case Event::OnEntry:
          do_open();
          startTimer( MaximumOpeningTime, TimerId::SwitchFailed );
          break;

        case Event::SwitchFailed:
          asyncTransitionTo( InternalState::Open ); break;
      }
      break;

  }
}


void
VirtualRelay::
asyncTransitionTo( InternalState newState )
{
  if( newState != currentState ) {
    targetState = newState;
    startTimer( 1, TimerId::NewState );
  }
}


void
VirtualRelay::
doTransition()
{
  if( targetState == currentState || targetState == InternalState::Undefined )
    return;

  auto oldGlobal = globalState;
  auto oldInternal = currentState;

  globalState = State_InternalToGlobal[ int( targetState )];
  currentState = targetState;
  targetState = InternalState::Undefined;

  notify( globalState, oldGlobal, currentState, oldInternal );

  processEvent( Event::OnEntry );
}


void
VirtualRelay::
processTimerEvent( TimerId timer )
{
  switch( timer )
  {
    case TimerId::NewState:
      doTransition();
      break;

    case TimerId::SwitchFailed:
      processEvent( Event::SwitchFailed );
      break;

    case TimerId::SwitchStable:
      processEvent( Event::AuxiliaryStable );
      break;
  }
}


void
VirtualRelay::
asyncInputsCheck()
{
  Debug.print( DBG_DEBUG, "DEBUG::Checking all digital inputs" );
  pio::forceGlobalChange();
}



// ---
// --- Timers
// ---

bool
VirtualRelay::
isTimerActive( TimerId timer )
{
  return timers[ int( timer )] != TimerDisabled;
}


void
VirtualRelay::
startTimer( timestamp_t delay, TimerId timer )
{
  timers[ int( timer )] = millis() + delay;
  computeNextTimeEvent();
}


void
VirtualRelay::
stopTimer( TimerId timer )
{
  timers[ int( timer )] = TimerDisabled;
}


void
VirtualRelay::
computeNextTimeEvent()
{
  nextTimeEvent = TimerDisabled;
  for( int i = 0; i < int( TimerId::COUNT ); ++i )
    nextTimeEvent = min( nextTimeEvent, timers[i] );
}


void
VirtualRelay::
timer_loop()
{
  // Wait until nextTimeEvent is due
  timestamp_t currentTime;
  do {
    Scheduler.yield();
    currentTime = millis();
  }
  while( nextTimeEvent > currentTime );

  // Loop on all timers
  for( int i = 0; i < int( TimerId::COUNT ); ++i )
  {
    if( timers[i] <= currentTime )
    {
      timers[i] = TimerDisabled;
      processTimerEvent( TimerId( i ));
    }
  }

  // Wait for next event
  computeNextTimeEvent();
}



// ---
// --- Debug Helpers
// ---

static
const char * const GlobalStateStrings[] = {
  "Open",
  "Closed",
  "Error",
  "Opening",
  "Closing",
  "Initializing",
};

static_assert( size(GlobalStateStrings) == int(GlobalState::Initializing) + 1,
    "Different size between Global States definitions and strings.");


const char * toString( GlobalState state )
{
  return GlobalStateStrings[ int(state) ];
}


static
const char * const InternalStateStrings[] = {
  "Open",
  "Closed",
  "Error",
  "Opening_Requested",
  "Opening",
  "Closing_Requested",
  "Closing",
  "Initializing",
  "Undefined",
};

static_assert( size(InternalStateStrings) == int(InternalState::Undefined) + 1,
    "Different size between Global States definitions and strings.");


/**
 * Returns a string corresponding to state
 */
const char * toString( InternalState state )
{
  return InternalStateStrings[ int(state) ];
}


static
const char * const EventStrings[] = {
  "OnEntry",
  "OpenRequest",
  "CloseRequest",
  "AuxiliaryClosed",
  "AuxiliaryUnknown",
  "AuxiliaryOpen",
  "AuxiliaryStable",
  "SwitchFailed",
};

static_assert( size(EventStrings) == int(Event::COUNT),
    "Different size between Events definitions and strings.");


const char * toString( Event event )
{
  return EventStrings[ int(event) ];
}


} // namespace
