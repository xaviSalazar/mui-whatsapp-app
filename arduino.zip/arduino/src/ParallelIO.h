/** \file
 * Management of the digital I/O pins.
 */
#pragma once

#include <stdint.h>


/// Management of the digital I/O pins.
namespace pio {


/// Number of Controllers for "Parallel IOs"
constexpr int ControllersCount = 4;

constexpr uint8_t A = 0;
constexpr uint8_t B = 1;
constexpr uint8_t C = 2;
constexpr uint8_t D = 3;


//
// --- Initialization
//

/// Structure for inputs & outputs of a PIO Controller
struct ControllerConfig_t
{
  uint32_t input_mask;
  uint32_t pullup_mask;
  uint32_t output_mask;
  uint32_t output_initial;
  uint32_t logical_mask;
  uint32_t pwm_mask;
};

/// Configuration for all PIO Controllers
using Config_t = struct ControllerConfig_t[ControllersCount];

/// Array with a 32-bits value for each PIO Controllers
using ControllersStatus_t = uint32_t[ControllersCount];


/**
 * Initializes all PIO controllers.
 *
 * \warning Only the “ENABLE” registers are used.
 *
 * \note If you want to call this method several times, it must be adapted to
 *       use the DISABLE registers *and* take into account the Arduino I/Os.
 */
void init(const Config_t &);


/**
 * Dumps current raw states to Debug serial.
 */
void dump();


/**
 * Dumps current logical states to Debug serial.
 */
void dump_logical();


//
// --- Outputs
//

/**
 * Changes ALL digital output pins to provided values.
 */
void setDigitalOutputs(const ControllersStatus_t & outputs);

/**
 * Return current states of ALL digital outputs.
 */
void getDigitalOutputs(ControllersStatus_t & outputs);


/// Define an output pin
struct OutputPin {
  uint8_t controller;
  uint8_t index;
};

/// Dummy Output pin.
/// - #write does nothing.
/// - #readOutput returns false
extern OutputPin const DummyOutput;


/**
 * Sets logical state of provided pin.
 *
 * “Logical State” means:
 * True when the pin is *active* from the application point of view
 * (even if that means writing a 0V state).
 */
void write( const OutputPin &, bool logical_state );

/**
 * Returns logical state of provided pin.
 *
 * \note: The method is labelled "Output" to make it explicit
 *        we are reading back our own output pin.
 */
bool readOutput( const OutputPin & );


//
// --- Inputs
//

/**
 * Gets ALL digital input pins raw values.
 *
 * \note A "1" means 3.3V.
 */
void getDigitalInputs(ControllersStatus_t & inputs);


/**
 * Gets ALL digital input pins converted to **logical** levels.
 *
 * \note A "1" means Active.
 */
void getInputsLogicalLevels(ControllersStatus_t & inputs);


/// Define an input pin
struct InputPin {
  uint8_t controller;
  uint8_t index;
};

/**
 * Returns logical state of provided pin.
 *
 * “Logical State” means:
 * True when the pin is *active* from the application point of view
 * (even if that means reading a 0V state).
 */
bool read( const InputPin & );


//
// --- Input Interrupts
//

/// Count of interrupts since last call to `clearInterrupts`
extern volatile uint8_t inputsChanged;

/// Returns inputs changes and clears states
void getInterrupts(ControllersStatus_t & status);

/// Clears all
void clearInterrupts();

/**
 * Simulates a full change of all inputs.
 *
 * This can be used to force a global re-analysis of all values.
 */
void forceGlobalChange();


} // namespace
