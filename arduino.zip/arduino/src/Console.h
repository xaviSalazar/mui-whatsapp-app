/** \file
 * "Console" provides some simple interactions with the end-user.
 */
#pragma once

///  This module provides the debug console.
namespace console {


/// True when “Debug level” messages must be printed.
extern bool show_debug_level;

/// Initialization
void init();


} // namespace
