/** \file
 * "CobsBuffer" provides COBS-related buffer manipulations.
 */
#pragma once


#include <array>
#include <cstdint>


/// This module provides memory management
namespace memory {


/** The InplaceBuffer class provides a buffer that do COBS-{de,en}coding "in place".
 *
 * COBS has 2 big features:
 * - it removes all zeroes from the encoded buffer.
 *   So the 0 value can be used as a frame separator at the transport layer;
 * - it only (and systematically) increases the size of the encoded data by 1
 *   byte per 254 bytes of data.
 *
 * So if you look at data processed by COBS, you see that by moving the start
 * of the encoded buffer by 1 byte, it is possible to leave all non-zero data
 * in place.
 *
 * \verbatim
 *    11 22 33 44 55    decoded
 * 06 11 22 33 44 55    encoded

 *    00 11 22 00 33 44 00 55 00    decoded
 * 01 03 11 22 03 33 44 02 55 01    encoded
 *
 *    00 00 00 00 00 00 00 00 00 00 00    decoded
 * 01 01 01 01 01 01 01 01 01 01 01 01    encoded
 * \endverbatim
 *
 *
 * \note
 *   The drawback of this in-place optimization is that no more than 254 bytes
 *   of data (i.e. a single full COBS block) can be encoded.
 *
 * Template argument N is the size of the decoded buffer.
 */
template< std::size_t N >
struct InplaceBuffer
{
  /// In-place encoding implies a single COBS block.
  static constexpr std::size_t MaximumDecodedSize = 0xFE;

  /// Maximum size of the decoded buffer (encoded buffer is N+1)
  static constexpr std::size_t max_size = N;

  static_assert( N <= MaximumDecodedSize,
      "Cannot encode in-place more than a single COBS block" );

  /// Type of byte elements
  using value_type = uint8_t;


  /// True when encode() has been called
  bool encoded = false;


  /// Returns a pointer to the data buffer, depending on #encoded
  value_type * data() { return data_ + (encoded? 0 : 1); }

  /**
   * Encode buffer.
   */
  void encode( std::size_t length );

  void decode( std::size_t length );

private:

  value_type data_ [N + 1];

};


template< std::size_t N >
void
InplaceBuffer<N>::
encode( std::size_t length )
{
  encoded = true;

  auto       *       dst = data_;
  auto const *       src = data_ + 1;
  auto const * const end = src + std::min( N, length );

  // Pointer to the beginning of COBS block (where we put the code)
  auto * code_ptr = dst++;
  value_type code = 0x01;

  while (src < end)
  {
    if (*src == 0) {
      // Found a zero: Finish block
      *code_ptr = code;
      code_ptr = dst;
      code = 0x01;
    }
    else
    {
      ++code;
      // No need to check whether we filled a COBS block:
      //   By construction, this class is limited to a single block.
    }
    ++src;
    ++dst;
  }

  // Finish last block
  *code_ptr = code;
};


template< std::size_t N >
void
InplaceBuffer<N>::
decode( std::size_t length )
{
  encoded = false;

  auto * ptr = data_;
  auto const * const end = ptr + std::min( N+1, length );

  auto code = *ptr;

  while (ptr < end)
  {
    *ptr = 0;
    ptr += code;
    code = *ptr;
  }
};


} // namespace
