#include "Console.h"

#include "Hardware.h"
#include "MonkeyIO.h"

#include <Arduino.h>
#include <Arduino_DebugUtils.h>
#include <Scheduler.h>


namespace console {


bool show_debug_level = false;


static uint8_t plug_leds_state = 0;


/// The input monitoring loop
static
void monitor_loop()
{
  await( SerialDebug.available() );

  bool forcePrint = false;

  while( SerialDebug.available() )
  {
    auto input = SerialDebug.read();
    bool upper = isupper(input);
    switch( input )
    {

      case '!': // Toggle DEBUG
        show_debug_level = ! show_debug_level;
        Debug.setDebugLevel( show_debug_level? DBG_DEBUG : DBG_INFO );
        break;

      case ' ':
        Debug.setDebugLevel( DBG_DEBUG );
        monkey::dumpRelays();
        monkey::dumpAnalog();
        Debug.setDebugLevel( show_debug_level? DBG_DEBUG : DBG_INFO );
        break;

      case 'o':
      case 'O':
        monkey::relay_OBC_PS->switch_to( upper );
        break;

      case 'p':
      case 'P':
        monkey::relay_OBC_DC->switch_to( upper );
        break;

      case 'w':
      case 'W':
        monkey::relay_WW_PS->switch_to( upper );
        break;

      case 'd':
      case 'D':
        monkey::relay_WW_DC->switch_to( upper );
        break;

      case 'a':
      case 'A':
        monkey::relay_WW_AC->switch_to( upper );
        break;

      case 'l':
      case 'L':
        monkey::relay_Load->switch_to( upper );
        break;

      case 'g':
      case 'G':
        monkey::plug_lock->switch_to( upper );
        break;

      case 'h':
        plug_leds_state = (plug_leds_state + 1) % 4;
        monkey::set_plug_led( plug_leds_state );
        break;

      case 'R':
        hardware::resetRequested = true;
        break;

      case '\n':
      case '\r':
        break;

      default:
        // Ignore
        break;
    }
  }
}


void init()
{
  Scheduler.startLoop( monitor_loop );
}


} // namespace
