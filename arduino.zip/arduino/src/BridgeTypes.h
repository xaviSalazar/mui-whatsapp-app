/** \file
 * "BridgeTypes" defines the types of messages exchanged between Arduino and peer.
 *
 * \see ArduinoTypes.hpp in GPIO bridge's project for the corresponding
 * definitions from the bridge point of view.
 */
#pragma once


#include <cstdint>


namespace bridge {


// ---
// --- Commands Definitions
// ---

/**
 * IDs of Command Targets
 */
enum TargetCommandId : uint8_t
{
  PlugLeds = 0x40,      ///< Plug LEDs management
  ResetArduino = 0xA5,  ///< Reset Arduino
};


/**
 * Index of the relays of the Monkey Board.
 *
 * \note The order is arbitrary but is shared with the remote peer.
 */
enum RelayIndex : uint8_t
{
  OBC_PS   = 0, ///< OBC Power Supply (12V)
  OBC_DC   = 1, ///< OBC DC
  WW_PS    = 2, ///< Watt&Well Power Supply (12V)
  WW_DC    = 3, ///< Watt&Well DC
  WW_AC    = 4, ///< Watt&Well AC
  Load     = 5, ///< Load
  PlugLock = 6, ///< Plug's Lock

  COUNT ///< Number of elements
};


/// Number of relays
constexpr auto RelaysCount = RelayIndex::COUNT;


/**
 * Arduino status of a relay.
 *
 * When auxiliary feedback is available, the status is based on what is read.
 * Otherwise, the status is a copy of the output command.
 */
enum RelayStatus : uint8_t
{

  /// Transient state, while waiting for the initial state.
  Initializing = 0,

  /// Unexpected auxiliary feedback.
  Error        = 1,

  /// Relay is open.
  Open         = 2,

  /// Relay is closed.
  Closed       = 3,

  /// Relay is opening and we're debouncing the auxiliary feedback.
  Opening      = 4,

  /// Relay is closing and we're debouncing the auxiliary feedback.
  Closing      = 5,

};


/// Type for electrical resistance value
using Resistance_t = uint16_t;

/// Value for high resistance
constexpr Resistance_t InfiniteResistance = 65535;


} // namespace
