/** \file
 * "BridgeMessages" defines the messages exchanged between Arduino and peer.
 *
 * \see ArduinoMessages.hpp in GPIO bridge's project for the corresponding
 * definitions from the bridge point of view.
 */
#pragma once


#include "BridgeTypes.h"


namespace bridge {


// ---
// --- Commands
// ---

/**
 * The Command class describes the format of commands received from the peer.
 */
struct Command
{
  uint8_t target;
  uint8_t action;
  uint8_t checksum;

  void computeChecksum() { checksum = (~target) xor action xor 0xA5; }
  bool isValid() const { return checksum == uint8_t((~target) xor action xor 0xA5); }
};


/// Action value used to ask for resetting the Arduino.
constexpr uint8_t ResetCommand_Action = 0x5A;


// ---
// --- Relays States
// ---

/**
 * The RelaySummary structure describes the state of a relay sent to the remote peer.
 */
union RelaySummary
{
  uint8_t byte;
  struct {
    RelayStatus status :6;   ///< RelayStatus value
    uint8_t     aux2   :1;   ///< True when auxiliary says "closed" (when applicable)
    uint8_t     aux1   :1;   ///< True when auxiliary says "closed" (when applicable)
  };
};

static_assert( sizeof(RelaySummary) == 1, "RelaySummary must fit in a single byte" );


/// The states of all relays.
using RelaysStates = RelaySummary[ RelaysCount ];


// ---
// --- Arduino's Summary
// ---

struct ArduinoSummary
{
  alignas(2)
  RelaysStates relays;

  alignas(2)
  Resistance_t proximity;
};

static_assert( sizeof(ArduinoSummary)
    == (RelaysCount+1)/2*2
    + sizeof(Resistance_t),
    "Unexpected size of ArduinoSummary" );


} // namespace
