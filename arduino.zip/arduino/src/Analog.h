/** \file
 * Management of the Analog to Digital converters of the Arduino.
 */
#pragma once

#include <stdint.h>

/// Namespace for using the Analog to Digital inputs pins.
namespace adc {


// ---
// --- Types & Constants
// ---

/// Type of raw ADC value
using Value_t = uint16_t;

/// Number of ADC Channels
constexpr int ChannelsCount = 16;

/// Maximum possible value
constexpr int MaxChannelValue = 4095;

/// Minimum delta (compared to cached value) to flag a new change
constexpr int MinDeltaValue = 32;


// ---
// --- Configuration
// ---

/**
 * Initializes ADC channels.
 *
 * \param pins_mask Active channels.
 */
void init( const uint16_t pins_mask );


/**
 * Changes active ADC channels.
 * This can be called anytime.
 */
void setActiveChannels( const uint16_t mask );


/**
 * Return the list of active ADC channels.
 */
uint16_t getActiveChannels();


// ---
// --- Debug
// ---

/**
 * Dumps all analog values.
 *
 * \note  Only *wait* for values *once*, just after having called `init`.
 *        Otherwise this is very, very likely that the application will be
 *        *stuck forever*!
 *
 * \param wait  If true, waits until getChangedChannels() == getActiveChannels()
 * \param reset If true, clears the changed channels bits
 */
void dump( bool wait, bool reset );


// ---
// --- Getter
// ---

/**
 * Returns a bit-array of ADC channels with changed values.
 */
uint16_t getChangedChannels();

/**
 * Returns latest value of requested channel.
 *
 * \param reset If true, the changed bit is cleared.
 */
Value_t getChannelValue( uint8_t index, bool reset );

/**
 * Simulates a full change of all inputs.
 *
 * This can be used to force a global re-analysis of all values.
 */
void forceGlobalChange();



} // namespace
