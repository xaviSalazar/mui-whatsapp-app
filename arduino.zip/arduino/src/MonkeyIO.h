/** \file
 * Links together the Arduino's hardware with the Monkey Board.
 */
#pragma once

#include <Arduino.h>


#include "BridgeTypes.h"
#include "MonkeyRelays.h"
#include "ParallelIO.h"


namespace monkey {


// ---
// --- Initialization
// ---

/// Initializes the module.
void init();


// ---
// --- Debug Helps
// ---

void dumpRelays();
void dumpAnalog();


// ---
// --- Digital Inputs
// ---

constexpr uint8_t DC_Relay_Qt = 2;


/// Auxiliary feedbacks for Relay #6
constexpr pio::InputPin OBC_DC_In[ DC_Relay_Qt ] = {
  { pio::C, 23 }, /// Relay #6.1
  { pio::C, 22 }  /// Relay #6.2
};

/// Auxiliary feedbacks for Relay #5
constexpr pio::InputPin WW_DC_In[ DC_Relay_Qt ] = {
  { pio::C, 25 }, // Relay #5.1
  { pio::C, 24 }  // Relay #5.2
};

/// Auxiliary feedback for Relay #7
constexpr pio::InputPin WW_AC_In { pio::C, 21 };

/// Auxiliary feedback for Relay #8
constexpr pio::InputPin Load_In { pio::A, 28 };

/// Feedback for Plug Lock
constexpr pio::InputPin PlugLock_In { pio::D, 7 };


// ---
// --- Digital Outputs
// ---

constexpr pio::OutputPin PlugLed_Green { pio::C,  8 };
constexpr pio::OutputPin PlugLed_Red   { pio::A, 19 };


// ---
// --- Analog to Digital Conversion
// ---

/// ADC Channel for Proximity P
constexpr uint8_t Proximity_adcChannel = 7;

/**
 * Returns measured resistance of PP
 *
 * \param reset \see analog::getChannelValue
 */
bridge::Resistance_t
proximity_resistance( bool reset = false );


// ---
// --- Outputs Management
// ---

void set_plug_led( uint8_t );


// ---
// --- Relays Handler
// ---

/**
 * The SimpleRelay structure describes a relay with just a Command pin
 * (and no LED).
 */
struct SimpleRelay
{
  const char * name; ///< Display (debug) name
  const bridge::RelayIndex index; ///< Index (shared with peer)
  pio::OutputPin command; ///< Command pin

  void switch_to( bool closed );
};

/// The Power Supply relay of the on-board charger
extern SimpleRelay * relay_OBC_PS;

/// The DC relay of the on-board charger
extern MonkeyRelay * relay_OBC_DC;

/// The Power Supply relay of the W&W PU
extern SimpleRelay * relay_WW_PS;

/// The DC relay of the W&W PU
extern MonkeyRelay * relay_WW_DC;

/// The AC relay of the W&W PU
extern MonkeyRelay * relay_WW_AC;

/// The relay of the V2L load
extern MonkeyRelay * relay_Load;

/// The relay of the Plug's lock
extern MonkeyRelay * plug_lock;

} // namespace
