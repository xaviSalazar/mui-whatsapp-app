#include "Analog.h"

#include <cstring>

#include <Arduino.h>
#include "Arduino_DebugUtils.h"


namespace adc {

#ifndef __SAM3X8E__
#  error "Expecting __SAM3X8E__ to be defined"
#endif
#ifndef SAM3X8
#  error "Expecting SAM3X8 to be defined"
#endif
#ifndef SAM3XA_SERIES
#  error "Expecting SAM3XA_SERIES to be defined"
#endif


//
// --- Frequency
//

/* I found the following bug:
 * - In FwUp mode, the last enabled channel (can be any number) is always
 *   “converted” to the mid-range value (200h in 10-bit mode & 800h in 12-bit).
 * - The bug is not present in FreeRun or when not sleeping.
 *
 * So I wanted to use AD15 as the last channel, but I'm in another bug
 * described there: https://forum.arduino.cc/index.php?topic=185326.0
 *
 * So, for the time being, I use the slowest possible freerun.
 */


//
// --- Cached Values
//

volatile uint16_t changedChannels = 0;

volatile uint16_t values[ ChannelsCount ] = {};


//
// --- Initialization
//

void init( const uint16_t mask )
{
  // Init the array with “impossible” values
  std::memset( (void*)values, 0xFF, sizeof(values) );

  // ADC Mode Register
  ADC->ADC_MR |=
    ADC_MR_USEQ_NUM_ORDER |
    1 << ADC_MR_TRANSFER_Pos |
    0 << ADC_MR_TRACKTIM_Pos |
    // ANACH
    ADC_MR_SETTLING_AST3 |
    7 << ADC_MR_STARTUP_Pos |
    15 << ADC_MR_PRESCAL_Pos |
    ADC_MR_FREERUN_ON |
    ADC_MR_FWUP_OFF |
    ADC_MR_SLEEP_NORMAL |
    ADC_MR_LOWRES_BITS_12 |
    // TRGSEL
    ADC_MR_TRGEN_DIS;

  adc_enable_tag( ADC );

  setActiveChannels( mask );
}


void setActiveChannels( const uint16_t mask )
{
  // First, stop anything
  NVIC_DisableIRQ( ADC_IRQn );
  NVIC_ClearPendingIRQ( ADC_IRQn );

  // Clear some bits
  ADC->ADC_LCDR; // Clear DRDY bit
  ADC->ADC_OVER; // Clear overrun bits

  // Enable ADC channels corresponding to given mask
  ADC->ADC_CHER = mask;

  if( mask )
  {
    // Start ADC clock
    pmc_enable_periph_clk( ID_ADC );

    // Enable Interrupts
    ADC->ADC_IER = ADC_IER_DRDY;
    NVIC_EnableIRQ( ADC_IRQn );
    NVIC_SetPriority( ADC_IRQn, 1 );

    // Start first conversion
    ADC->ADC_CR = ADC_CR_START;
  }
  else
  {
    // Stop conversion
    pmc_disable_periph_clk( ID_ADC );
  }
}


uint16_t getActiveChannels()
{
  return ADC->ADC_CHSR;
}


static const char* const ArduinoPins[ ChannelsCount ] = {
  "A7 ", "A6 ", "A5 ", "A4 ", "A3 ", "A2 ", "A1 ", "A0 ",
  "p20", "p21", "A8 ", "A9 ", "A10", "A11", "p52", "Tem"
};

void dump( bool wait, bool reset )
{
  auto active = getActiveChannels();

  Debug.print(DBG_DEBUG, "Analog inputs (%04X)", active);

  // Wait for all channels to have a value
  if( wait )
  {
    uint16_t values;
    do {
      values = getChangedChannels();
    } while ( values & active != active );
  }

  // Dump active channels
  for( int mask = 1, ch = 0; ch < ChannelsCount; ++ch, mask <<= 1 )
    if( active & mask )
    {
      Debug.print(DBG_DEBUG, "AD%-2i - %s = %i",
          ch,
          ArduinoPins[ch],
          getChannelValue(ch, reset));
    }

  Debug.print(DBG_DEBUG, "");
}


Value_t getChannelValue( uint8_t channel, bool reset )
{
  if( channel >= ChannelsCount )
    return 0;

  if( reset )
  {
    ::noInterrupts();

    // Retrieve current value AND update cached value
    Value_t val
      = adc::values[ channel ]
      = * ( ADC->ADC_CDR + channel );

    // Clear corresponding bit
    changedChannels &= ~ ( 1 << channel );

    ::interrupts();

    return val;
  }

  // Read register but don't clear the “changed” bit
  return * ( ADC->ADC_CDR + channel );

}


uint16_t getChangedChannels()
{
  return changedChannels;
}


void forceGlobalChange()
{
  ::noInterrupts();

  changedChannels = getActiveChannels();

  ::interrupts();
}


} // namespace



extern "C" {

  void ADC_Handler(void)
  {
    uint16_t lcdr = ADC->ADC_LCDR;
    uint16_t channel = (lcdr & ADC_LCDR_CHNB_Msk) >> ADC_LCDR_CHNB_Pos;
    if( channel < adc::ChannelsCount )
    {
      uint16_t current = (lcdr & ADC_LCDR_LDATA_Msk) >> ADC_LCDR_LDATA_Pos;
      auto previous = adc::values[ channel ];

      uint16_t diff = current > previous ? current - previous : previous - current;

      if( diff >= adc::MinDeltaValue )
        adc::changedChannels |= 1 << channel;
    }
  }

}
