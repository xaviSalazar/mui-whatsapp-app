/** \file
 * The “LED Feedback” uses the “L” LED to provide feedback to the end-user.
 */

#pragma once

/// The “LED Feedback” uses the “L” LED to provide feedback to the end-user.
namespace feedback {


/// Initializes the LED
void led_setup();

/// Actions to do periodically
void led_loop();

enum LedState {
  Error,
  Active,
};

/// Requested state of the LED
extern volatile LedState state;

} // namespace
