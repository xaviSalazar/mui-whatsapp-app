/** \file
 * Defines the low-level hardware of the Arduino Due micro-controller.
 */
#pragma once

#include <Arduino.h>

#include "ParallelIO.h"

#include <watchdog.h>

/// This module defines the low-level hardware configuration of the
/// Arduino Due micro-controller.
namespace hardware {


/// The Serial UART to use for debugging & printing purpose
#define SerialDebug SerialUSB

/// Baudrate of the debug UART
constexpr uint32_t SerialDebug_Baudrate = 115200;


/// The Serial UART to use for the Machine-to-Machine stream
#define SerialM2M Serial

/// Baudrate of the debug UART
constexpr uint32_t SerialM2M_Baudrate = 115200;


/** Structure for a global DUE configuration
 *
 * Parallel IO
 * -----------
 * Use the associated “Hardware.ods” sheet to easily compute the configuration
 * values.
 *
 * Analog Input Channels
 * ---------------------
 *  SAM3X & Arduino's pinouts use a different numbering scheme!
 *
 *  SAM3X | Arduino
 * -------|---------
 *   AD0  | A7
 *   AD1  | A6
 *   AD2  | A5
 *   AD3  | A4
 *   AD4  | A3
 *   AD5  | A2
 *   AD6  | A1
 *   AD7  | A0
 *   AD8  | 20 SDA
 *   AD9  | 21 SCL
 *   AD10 | A8
 *   AD11 | A9
 *   AD12 | A10
 *   AD13 | A11
 *   AD14 | 52 RxD2
 *   AD15 | Internal SAM3 temp. sensor
 */
struct Global_t
{
  const char * const title; ///< Title of the configuration
  pio::Config_t pio; ///< PIO configuration
  uint16_t analog; ///< Analog inputs (SAM3X pinout)
};


/// Configuration of the pins
extern const Global_t pinout;

constexpr uint16_t AnalogMask = 0x0080;


/**
 * Initializes the hardware of the board.
 *
 * Calls PIO & Analog init functions.
 */
void init();


// ---
// --- WatchDog
// ---

/// Delay before activation of the watch-dog
constexpr int WatchDogTriggerDelay = 2000; // millisec

/// True when a reset of the board is requested
extern bool resetRequested;

/// Must be called periodically to restart the watch-dog timer
inline
void watchdogReset (void) { if(!resetRequested) ::watchdogReset(); }


}
