/** \file
 * "BridgeManager" exchanges messages with a peer through UART.
 */
#pragma once


#include "BridgeTypes.h"
#include "BridgeMessages.h"


/// Manages the messages exchanged with the remote peer.
/// The low-level management is provided by SerialMonitor.
namespace bridge {


// ---
// --- Initialization
// ---

/// Initializes the module.
void init();


// ---
// --- Commands
// ---

/// Called by serial::receive_loop when a command has been received.
void process_command( const Command * );


// ---
// --- Analog Update
// ---

/// Called by monkey::analog_monitor when a new value is available
void proximity_changed( Resistance_t );


// ---
// --- Relays Statuses
// ---

/// Called by monkey::SimpleRelay & monkey::MonkeyRelay when a relay status has changed.
void relay_status_changed( RelayIndex, RelayStatus );


// ---
// --- Auxiliaries Update
// ---

/// Called by monkey::digital_monitor when a relay feedback has changed.
void relay_changed( RelayIndex, bool aux );

/// Called by monkey::digital_monitor when a relay feedback has changed.
void relay_changed( RelayIndex, bool aux[2] );


} // namespace
