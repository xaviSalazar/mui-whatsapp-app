#include "LedFeedback.h"

#include <Arduino.h>

#include <Scheduler.h>


namespace feedback {


constexpr uint32_t LED_ID = LED_BUILTIN;


const uint32_t config[][4] = {
  // OFF   ON  OFF   ON
  {   60,  40,  60,  40 }, // Error
  {  850,  50,  50,  50 }, // Active
};


volatile LedState state = Active;


// Time of the next change
static uint32_t target_time;


void led_setup()
{
  pinMode(LED_ID, OUTPUT);
  target_time = GetTickCount();
}


// Wait until delay elapsed or state has changed
static inline
void wait(int step)
{
  // Change HW LED state
  digitalWrite(LED_ID, step & 1);

  // Remember current “LedState” (to be compared to volatile state variable)
  LedState current = state;

  // New time target
  target_time += config[current][step];

  // Wait
  await( GetTickCount() >= target_time || current != state);
}

void led_loop()
{
  wait(0);
  wait(1);
  wait(2);
  wait(3);
}


} // namespace
