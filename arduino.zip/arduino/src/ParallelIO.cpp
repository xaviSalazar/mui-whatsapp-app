#include "Hardware.h"
#include "ParallelIO.h"

#include <cstring>

#include <Arduino.h>
#include "Arduino_DebugUtils.h"


namespace pio {


/// The PIO Controllers
static
const struct { uint8_t id; IRQn_Type irq_id; Pio* pio; }
Controllers[ControllersCount] = {
  { ID_PIOA, PIOA_IRQn, PIOA },
  { ID_PIOB, PIOB_IRQn, PIOB },
  { ID_PIOC, PIOC_IRQn, PIOC },
  { ID_PIOD, PIOD_IRQn, PIOD }
};


//
// --- Initialization
//

void init( const Config_t & config )
{
  for( int i = 0; i < ControllersCount; ++i )
  {

    // === Clock ===

    pmc_enable_periph_clk(Controllers[i].id);


    // === PIOs ===

    auto pio = Controllers[i].pio;
    auto input_mask = config[i].input_mask;
    auto pullup_mask = config[i].pullup_mask;
    auto output_mask = config[i].output_mask;
    auto output_init = config[i].output_initial;
    auto pwm_mask = config[i].pwm_mask;

    // --- Main Register ---

    pio->PIO_PER = input_mask | output_mask;
    pio->PIO_PDR = pwm_mask;


    // --- Input Settings ---

    // Interrupt Enable
    pio->PIO_IER = input_mask;

    // Pull-up
    pio->PIO_PUER = pullup_mask;
    // Explicitly disable other inputs
    pio->PIO_PUDR = input_mask & ~pullup_mask;

    // Unused features:
    // - Glitch Input Filter
    // - Multi-driver


    // --- Output Settings ---

    // Note:
    //    arduino_due_x/variant.cpp enables all pins in init() but never uses it
    // Output Write Enable
    pio->PIO_OWER = output_mask;
    pio->PIO_OWDR = 0xFFffFFffu & (~output_mask);

    // Output Data Status
    pio->PIO_ODSR = output_init;

    // Output Enable
    pio->PIO_OER = output_mask;


    // --- A/B Peripherals ---

    // All PWMs lines are on Peripheral B
    pio->PIO_ABSR = pwm_mask;
    // TODO Maybe OR with existing setting?


    // === Interrupts ===

    auto irq_id = Controllers[i].irq_id;
    NVIC_DisableIRQ(irq_id);
    NVIC_ClearPendingIRQ(irq_id);
    NVIC_SetPriority(irq_id, 0);
    NVIC_EnableIRQ(irq_id);

  }

  // Clear transitory interrupts
  clearInterrupts();
}


//
// --- Debug
//

void dump()
{
  Debug.print(DBG_DEBUG, "        IN       OUT      a/B (PWM)");

  for( int i = 0; i < ControllersCount; ++i )
  {
    auto pio = Controllers[i].pio;
    Debug.print(DBG_DEBUG, "PIO %c = %08X %08X %08X",
        'A'+i,
        pio->PIO_PDSR & pio->PIO_IMR,
        pio->PIO_ODSR & ~pio->PIO_IMR,
        pio->PIO_ABSR );
  }

  Debug.print(DBG_DEBUG, "");
}


void dump_logical()
{
  Debug.print(DBG_DEBUG, "Logical IN       OUT      Mask");

  for( int i = 0; i < ControllersCount; ++i )
  {
    auto pio = Controllers[i].pio;
    auto pinout = hardware::pinout.pio[ i ];
    auto logical_mask = pinout.logical_mask;
    Debug.print(DBG_DEBUG, "PIO %c = %08X %08X %08X",
        'A'+i,
        compl( logical_mask xor pio->PIO_PDSR ) bitand pinout.input_mask,
        compl( logical_mask xor pio->PIO_ODSR ) bitand pinout.output_mask,
        logical_mask
    );
  }

  Debug.print(DBG_DEBUG, "");
}


//
// --- Outputs
//

OutputPin const DummyOutput { 0xFF, 0 };


void setDigitalOutputs(const ControllersStatus_t & outputs)
{
  for( int i = 0; i < ControllersCount; ++i )
  {
    auto pio = Controllers[i].pio;
    pio->PIO_ODSR = outputs[i] & pio->PIO_OSR;
  }
}


void getDigitalOutputs(ControllersStatus_t & outputs)
{
  for( int i = 0; i < ControllersCount; ++i )
  {
    auto pio = Controllers[i].pio;
    outputs[i] = (pio->PIO_ODSR & pio->PIO_OSR);
  }
}


void write( const OutputPin & pin, bool logical_state )
{
  if( pin.controller >= pio::ControllersCount )
    return;

  uint32_t pin_mask = (1u << pin.index);

  // True if active level is High
  bool logical_mask = pin_mask & hardware::pinout.pio[ pin.controller ].logical_mask;

  // Set physical level of pin
  auto pio = Controllers[ pin.controller ].pio;
  if( logical_state xor logical_mask )
    pio->PIO_CODR = pin_mask; // Low (mask != target)
  else
    pio->PIO_SODR = pin_mask; // High (mask == target)
}


bool readOutput( const OutputPin & pin )
{
  if( pin.controller >= pio::ControllersCount )
    return pin.index;

  uint32_t pin_mask = (1u << pin.index);

  // True if active level is High
  bool logical_mask = pin_mask & hardware::pinout.pio[ pin.controller ].logical_mask;

  // True if pin is High
  auto pio = Controllers[ pin.controller ].pio;
  bool physical_state = pio->PIO_ODSR & (1u << pin.index);

  return not ( physical_state xor logical_mask );
}



//
// --- Input
//

void getDigitalInputs(ControllersStatus_t & inputs)
{
  for( int i = 0; i < ControllersCount; ++i )
  {
    auto pio = Controllers[i].pio;
    inputs[i] = (pio->PIO_PDSR & pio->PIO_IMR);
  }
}


void getInputsLogicalLevels(ControllersStatus_t & inputs)
{
  for( int i = 0; i < ControllersCount; ++i )
  {
    auto pio = Controllers[i].pio;
    uint32_t logical_mask = hardware::pinout.pio[ i ].logical_mask;
    inputs[i] = compl ( logical_mask xor pio->PIO_PDSR ) bitand pio->PIO_IMR;
  }
}


bool read( const InputPin & pin )
{
  uint32_t pin_mask = (1u << pin.index);

  // True if active level is High
  bool logical_mask = pin_mask & hardware::pinout.pio[ pin.controller ].logical_mask;

  auto pio = Controllers[ pin.controller ].pio;
  return ! ( pio->PIO_PDSR & (1u << pin.index) );
}



//
// --- Input Interrupts
//

volatile uint8_t inputsChanged = 0;

/// Cumulated statuses of input changes
static volatile ControllersStatus_t interrupts = { 0, 0, 0, 0 };

// Returns interrupts
void getInterrupts(ControllersStatus_t & status)
{
  ::noInterrupts();

  // Interrupts are disabled, so we can throw away the `volatile` modifier
  std::memcpy(
      & status,
      const_cast<ControllersStatus_t*>(&interrupts),
      sizeof(ControllersStatus_t));

  clearInterrupts(); // and re-authorize interrupts
}

// Clears interrupts
void clearInterrupts()
{
  ::noInterrupts();

  // Interrupts are disabled, so we can throw away the `volatile` modifier
  std::memset(
      const_cast<ControllersStatus_t*>(&interrupts),
      0,
      sizeof(ControllersStatus_t));

  inputsChanged = 0;

  ::interrupts();
}


void forceGlobalChange()
{
  ::noInterrupts();

  // Interrupts are disabled, so we can throw away the `volatile` modifier
  std::memset(
      const_cast<ControllersStatus_t*>(&interrupts),
      0xFF,
      sizeof(ControllersStatus_t));

  inputsChanged = 1;

  ::interrupts();
}


} // namespace


extern "C" {

  void PIOA_Handler(void) {
    pio::interrupts[0] |= REG_PIOA_ISR & REG_PIOA_IMR;
    ++pio::inputsChanged;
  }

  void PIOB_Handler(void) {
    pio::interrupts[1] |= REG_PIOB_ISR & REG_PIOB_IMR;
    ++pio::inputsChanged;
  }

  void PIOC_Handler(void) {
    pio::interrupts[2] |= REG_PIOC_ISR & REG_PIOC_IMR;
    ++pio::inputsChanged;
  }

  void PIOD_Handler(void) {
    pio::interrupts[3] |= REG_PIOD_ISR & REG_PIOD_IMR;
    ++pio::inputsChanged;
  }

}

