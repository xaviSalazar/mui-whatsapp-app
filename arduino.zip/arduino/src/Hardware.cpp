#include "Hardware.h"

#include "Analog.h"

#include <Arduino_DebugUtils.h>


namespace hardware {

/**
 * \note Use the sheet “Hardware.ods” to easily create the PIO constants.
 *
 * \warning
 *    The input pins must also be updated in MonkeyIO.h.
 *    The output pins must also be updated in monkey::init.
 */
const Global_t pinout =
{
  // Title
  "ACE-MB v1.4",

  // PIO Configuration
  {
    {
      0x10000000, // In
      0x00000000, // Pull-up
      0x00180000, // Out
      0x00100000, // Out Init
      0x00080000, // Active
      0x00000000, // PWM
    },
    {
      0x00000000, // In
      0x00000000, // Pull-up
      0x00004000, // Out
      0x00004000, // Out Init
      0x00000000, // Active
      0x00000000, // PWM
    },
    {
      0x03E00000, // In
      0x00000000, // Pull-up
      0x00055354, // Out
      0x00055240, // Out Init
      0x00000154, // Active
      0x00000000, // PWM
    },
    {
      0x00000080, // In
      0x00000000, // Pull-up
      0x00000608, // Out
      0x00000000, // Out Init
      0x00000608, // Active
      0x00000000, // PWM
    }
  },

  // Analog input channels
  // NB: Order is different from Arduino's pin numbering
  AnalogMask,

};


void init()
{
  pio::init( pinout.pio );
  adc::init( pinout.analog );

  // Give some time for client to connect...
  delay(333);

  Debug.print( DBG_WARNING, "\n\nHardware %s\n", pinout.title );
  pio::dump();
  adc::dump( true, false );
}


} // Namespace


// ---
// --- WatchDog
// ---

bool hardware::resetRequested = false;

void watchdogSetup (void)
{
  watchdogEnable( hardware::WatchDogTriggerDelay );
}
