#include "MonkeyIO.h"

#include "Analog.h"
#include "BridgeManager.h"
#include "Hardware.h"
#include "ParallelIO.h"


// Third-party Libraries
#include <Arduino_DebugUtils.h>
#include <Scheduler.h>


// See https://stackoverflow.com/questions/41093090/esp8266-error-macro-min-passed-3-arguments-but-takes-just-2?answertab=active#tab-top
#undef min
#undef max
#include <cstring>
#include <limits>


namespace monkey {


// ---
// --- Types Definitions
// ---

static void monitor_loop();


// ---
// --- Module initialization
// ---

void init()
{

  relay_OBC_PS = new SimpleRelay {
    "OBC Pow.Sup",
    bridge::RelayIndex::OBC_PS,
    { pio::A, 20 }  // command
  };

  relay_OBC_DC = new MonkeyRelay {
    bridge::RelayIndex::OBC_DC,
    "OBC DC     ",
    { pio::C, 16 }, // command
    { pio::D,  9 }  // LED
  };

  relay_WW_PS = new SimpleRelay {
    "WW  Pow.Sup",
    bridge::RelayIndex::WW_PS,
    { pio::C, 18 }, // command
  };

  relay_WW_DC = new MonkeyRelay {
    bridge::RelayIndex::WW_DC,
    "WW  DC     ",
    { pio::C, 14 }, // command
    { pio::C,  4 }  // LED
  };

  relay_WW_AC = new MonkeyRelay {
    bridge::RelayIndex::WW_AC,
    "WW  AC     ",
    { pio::C, 12 }, // command
    { pio::C,  2 }  // LED
  };

  relay_Load = new MonkeyRelay {
    bridge::RelayIndex::Load,
    "  Load     ",
    { pio::B, 14 }, // command
    { pio::D,  3 }  // LED
  };

  plug_lock = new MonkeyRelay {
    bridge::RelayIndex::PlugLock,
    "  Plug     ",
    { pio::C,  9 }, // command
    { pio::D, 10 }  // LED
  };

  Scheduler.startLoop( monitor_loop );

  dumpRelays();

}


// ---
// --- Debug Helpers
// ---

/** Debug: Print OBC PS state */
static
void print_OBC_PS_relay()
{
  auto cmd = readOutput( relay_OBC_PS->command );
  Debug.print(DBG_DEBUG, "OBC Pow.Sup > %d", cmd );
}

/** Debug: Print OBC DC state */
static
void print_OBC_DC_relays( bool in1, bool in2 )
{
  auto cmd = readOutput( relay_OBC_DC->command );
  if( Debug_PrintGlobalStatesAsStrings )
    Debug.print(DBG_DEBUG, "OBC DC      > %d  < %d %d - %s",
        cmd, in1, in2, toString( relay_OBC_DC->globalState ));
  else
    Debug.print(DBG_DEBUG, "OBC DC      > %d  < %d %d - S#%d",
        cmd, in1, in2, relay_OBC_DC->globalState);
}

/** Debug: Print W&W PS state */
static
void print_WW_PS_relay()
{
  auto cmd = readOutput( relay_WW_PS->command );
  Debug.print(DBG_DEBUG, "WW  Pow.Sup > %d", cmd );
}

/** Debug: Print W&W DC state */
static
void print_WW_DC_relays( bool in1, bool in2 )
{
  auto cmd = readOutput( relay_WW_DC->command );
  if( Debug_PrintGlobalStatesAsStrings )
    Debug.print(DBG_DEBUG, "WW  DC      > %d  < %d %d - %s",
        cmd, in1, in2, toString( relay_WW_DC->globalState ));
  else
    Debug.print(DBG_DEBUG, "WW  DC      > %d  < %d %d - S#%d",
        cmd, in1, in2, relay_WW_DC->globalState);
}

/** Debug: Print W&W AC state */
static
void print_WW_AC_relay( bool in )
{
  auto cmd = readOutput( relay_WW_AC->command );
  if( Debug_PrintGlobalStatesAsStrings )
    Debug.print(DBG_DEBUG, "WW  AC      > %d  < %d   - %s",
        cmd, in, toString( relay_WW_AC->globalState ));
  else
    Debug.print(DBG_DEBUG, "WW  AC      > %d  < %d   - S#%d",
        cmd, in, relay_WW_AC->globalState );
}

/** Debug: Print Load state */
static
void print_Load_relay( bool in )
{
  auto cmd = readOutput( relay_Load->command );
  if( Debug_PrintGlobalStatesAsStrings )
    Debug.print(DBG_DEBUG, "    Load    > %d  < %d   - %s",
        cmd, in, toString( relay_Load->globalState ));
  else
    Debug.print(DBG_DEBUG, "    Load    > %d  < %d   - S#%d",
        cmd, in, relay_Load->globalState );
}

/** Debug: Print Plug Lock state */
static
void print_plug_lock( bool in )
{
  auto cmd = readOutput( plug_lock->command );
  if( Debug_PrintGlobalStatesAsStrings )
    Debug.print(DBG_DEBUG, "    Plug    > %d  < %d   - %s",
        cmd, in, toString( plug_lock->globalState ));
  else
    Debug.print(DBG_DEBUG, "    Plug    > %d  < %d   - S#%d",
        cmd, in, plug_lock->globalState );
}


/** Debug: Print all relays states */
void dumpRelays()
{
  print_OBC_PS_relay();
  print_OBC_DC_relays( read( OBC_DC_In[0] ), read( OBC_DC_In[1] ));
  print_WW_PS_relay();
  print_WW_DC_relays( read( WW_DC_In[0] ), read( WW_DC_In[1] ));
  print_WW_AC_relay( read( WW_AC_In ));
  print_Load_relay( read( Load_In ));
  print_plug_lock( read( PlugLock_In ));
}


/** Debug: Print analog Proximity P. value */
static
void print_proximity_p( bridge::Resistance_t value )
{
  Debug.print(DBG_DEBUG, "PP < %d Ohm", value);
}

/** Debug: Print analog values */
void dumpAnalog()
{
  print_proximity_p( proximity_resistance( false ));
}


// ---
// --- Digital Input Monitoring
// ---


/// Returns state of given pin
static inline
bool pinState( const pio::InputPin & pin, const pio::ControllersStatus_t & values )
{
  return values[ pin.controller ] & 1 << pin.index;
}


/// Monitor the digital pins for changes
static
void digital_monitor()
{
  using namespace bridge;
  using namespace relay;

  //    Use "static" variables so they are not on the stack
  //    => This is OK because monitor_loop is never called twice concurrently.
  //    Keep the smallest time-gap between clearing & reading
  static pio::ControllersStatus_t interrupts;
  static pio::ControllersStatus_t logical_levels;

  pio::getInterrupts( interrupts );
  pio::getInputsLogicalLevels( logical_levels );

  bool changed;
  bool relays[ DC_Relay_Qt ];

  // OBC DC relays
  //
  changed = false;
  for( int i = 0; i < DC_Relay_Qt; ++i )
  {
    relays[i] = pinState( OBC_DC_In[i], logical_levels );
    changed |=  pinState( OBC_DC_In[i], interrupts );
  }

  if( changed )
  {
    print_OBC_DC_relays( relays[0], relays[1] );

    bridge::relay_changed( RelayIndex::OBC_DC, relays );

    Event event =
      relays[0] != relays[1]
      ? Event::AuxiliaryUnknown
      : ( relays[0] ? Event::AuxiliaryClosed : Event::AuxiliaryOpen );

    relay_OBC_DC->processEvent( event );
  }

  // WW DC relays
  //
  changed = false;
  for( int i = 0; i < DC_Relay_Qt; ++i )
  {
    relays[i] = pinState( WW_DC_In[i], logical_levels );
    changed |=  pinState( WW_DC_In[i], interrupts );
  }

  if( changed )
  {
    print_WW_DC_relays( relays[0], relays[1] );

    bridge::relay_changed( RelayIndex::WW_DC, relays );

    Event event =
      relays[0] != relays[1]
      ? Event::AuxiliaryUnknown
      : ( relays[0] ? Event::AuxiliaryClosed : Event::AuxiliaryOpen );

    relay_WW_DC->processEvent( event );
  }

  // WW AC relay
  //
  if( pinState( WW_AC_In, interrupts ))
  {
    bool closed = pinState( WW_AC_In, logical_levels );
    print_WW_AC_relay( closed );
    bridge::relay_changed( RelayIndex::WW_AC, closed );
    relay_WW_AC->processEvent( closed ? Event::AuxiliaryClosed : Event::AuxiliaryOpen );
  }

  // Load relay
  //
  if( pinState( Load_In, interrupts ))
  {
    bool closed = pinState( Load_In, logical_levels );
    print_Load_relay( closed );
    bridge::relay_changed( RelayIndex::Load, closed );
    relay_Load->processEvent( closed ? Event::AuxiliaryClosed : Event::AuxiliaryOpen );
  }

  // Plug Lock
  //
  if( pinState( PlugLock_In, interrupts ))
  {
    bool closed = pinState( PlugLock_In, logical_levels );
    print_plug_lock( closed );
    bridge::relay_changed( RelayIndex::PlugLock, closed );
    plug_lock->processEvent( closed ? Event::AuxiliaryClosed : Event::AuxiliaryOpen );
  }

}


// ---
// --- Analog Input Monitoring
// ---

constexpr uint16_t AnalogMask =
  1 << Proximity_adcChannel;

static_assert( AnalogMask == hardware::AnalogMask, "AnalogMasks don't match" );


bridge::Resistance_t
proximity_resistance( bool reset )
{
  constexpr bridge::Resistance_t PullUp { 1500 };
  constexpr bridge::Resistance_t MaxValue { 65535 };
  constexpr adc::Value_t MaxMeasurableValue { 4000 };

  auto measure = adc::getChannelValue( Proximity_adcChannel, reset );

  if( measure >= MaxMeasurableValue )
    return MaxValue;

  uint32_t result = PullUp * measure;
  result /= adc::MaxChannelValue - measure;

  return result;
}


static
void analog_monitor()
{
  // !!!
  // If more than one Analog input, we MUST check which one has changed!
  // !!!

  // Proximity P.
  auto value = proximity_resistance( true );
  bridge::proximity_changed( value );
}


// ---
// --- Monitoring Loop
// ---

static
void monitor_loop()
{
  // Wait for some changes
  await( pio::inputsChanged != 0 || adc::getChangedChannels() & AnalogMask );

  // Check for changes
  if( pio::inputsChanged )
    digital_monitor();

  analog_monitor();

  // Force Scheduler to check the other loops
  // (Needed to avoid using all CPU if inputs are “floating”)
  yield();
}


// ---
// --- Outputs Management
// ---

void set_plug_led( uint8_t action )
{
  pio::write( PlugLed_Green, action & 1 );
  pio::write( PlugLed_Red,   action & 2 );
}


// ---
// --- Relays Handler
// ---

void
SimpleRelay::
switch_to( bool closed )
{
  pio::write( command, closed );

  auto status = closed? bridge::RelayStatus::Closed : bridge::RelayStatus::Open;
  bridge::relay_status_changed( index, status );

  auto global = closed? relay::GlobalState::Closed : relay::GlobalState::Open;
  if( Debug_PrintGlobalStatesAsStrings )
    Debug.print( DBG_INFO, "%s : %s", name, relay::toString( global ));
  else
    Debug.print( DBG_INFO, "%s : %d", name, global );
}


SimpleRelay * relay_OBC_PS = nullptr;

MonkeyRelay * relay_OBC_DC = nullptr;

SimpleRelay * relay_WW_PS = nullptr;

MonkeyRelay * relay_WW_DC = nullptr;

MonkeyRelay * relay_WW_AC = nullptr;

MonkeyRelay * relay_Load = nullptr;

MonkeyRelay * plug_lock = nullptr;


} // namespace
