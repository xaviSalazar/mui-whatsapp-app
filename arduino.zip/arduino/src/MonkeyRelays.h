/** \file
 * Contains specialized classes to handle Monkey Board's relays.
 */
#pragma once


// Project modules
#include "BridgeTypes.h"
#include "ParallelIO.h"
#include "RelayManager.h"


// Third-party Libraries
#include <Arduino.h>


/// This module provides relays management compatible with the Monkey Board pinout.
namespace monkey {


/// True when debug logs translate SM states into strings
constexpr bool Debug_PrintGlobalStatesAsStrings = true;


/**
 * The MonkeyRelay class manages the output pins of a relay (command & LED).
 */
class MonkeyRelay : public relay::VirtualRelay
{
public:

  MonkeyRelay(
      bridge::RelayIndex,
      const char * name,
      const pio::OutputPin & cmd,
      const pio::OutputPin & led );

  const char * name; ///< Display (debug) name

  const bridge::RelayIndex index; ///< Index (shared with peer)

  const pio::OutputPin command; ///< Command pin

  const pio::OutputPin led; ///< LED pin

private:

  void do_open() override;

  void do_close() override;

  void notify(
      relay::GlobalState newGlobal, relay::GlobalState oldGlobal,
      relay::InternalState newInternal, relay::InternalState oldInternal) override;

};


} // namespace
